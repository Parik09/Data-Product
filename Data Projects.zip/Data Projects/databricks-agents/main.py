from typing import Any, Dict, List, Optional
import asyncio
import yaml
from pathlib import Path

from .agents import (
    SupportEngineerAgent,
    DataEngineerAgent,
    PlannerAgent,
    ReviewerAgent,
    DataQualityAgent,
    CostOptimizationAgent,
    AgentConfig,
    AgentType,
    AgentContext,
    Task,
)
from .orchestration import AgentGateway, AgentRequest, AgentResponse
from .databricks import DatabricksClient
from .storage import AgentMemory, KPIRegistry, IncidentHistory, SemanticModel
from .utils import AgentLogger


class AgentPlatform:
    def __init__(self, config_path: str = "config/config.yaml"):
        self.config = self._load_config(config_path)
        self.logger = AgentLogger()
        self.databricks_client = None
        self.gateway = None
        self.memory = AgentMemory()
        self.kpi_registry = KPIRegistry()
        self.incident_history = IncidentHistory()
        self.semantic_model = SemanticModel()
        self._agents = {}

    def _load_config(self, config_path: str) -> Dict[str, Any]:
        try:
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            return self._get_default_config()

    def _get_default_config(self) -> Dict[str, Any]:
        return {
            "databricks": {
                "workspace_url": "https://your-workspace.cloud.databricks.com"
            },
            "agents": {
                "support_engineer": {"enabled": True},
                "data_engineer": {"enabled": True},
                "planner": {"enabled": True},
                "reviewer": {"enabled": True},
                "data_quality": {"enabled": True},
                "cost_optimization": {"enabled": True}
            },
            "environment": "dev"
        }

    def initialize(self):
        db_config = self.config.get("databricks", {})
        self.databricks_client = DatabricksClient(
            workspace_url=db_config.get("workspace_url", ""),
            token=db_config.get("api_token")
        )

        self.gateway = AgentGateway(self.config)

        self._initialize_agents()

        self.logger.logger.info("Agent Platform initialized successfully")

    def _initialize_agents(self):
        agent_configs = self.config.get("agents", {})

        support_config = AgentConfig(
            enabled=agent_configs.get("support_engineer", {}).get("enabled", True)
        )
        self._agents[AgentType.SUPPORT_ENGINEER] = SupportEngineerAgent(support_config)

        de_config = AgentConfig(
            enabled=agent_configs.get("data_engineer", {}).get("enabled", True)
        )
        self._agents[AgentType.DATA_ENGINEER] = DataEngineerAgent(de_config)

        planner_config = AgentConfig(
            enabled=agent_configs.get("planner", {}).get("enabled", True)
        )
        self._agents[AgentType.PLANNER] = PlannerAgent(planner_config)

        reviewer_config = AgentConfig(
            enabled=agent_configs.get("reviewer", {}).get("enabled", True)
        )
        self._agents[AgentType.REVIEWER] = ReviewerAgent(reviewer_config)

        quality_config = AgentConfig(
            enabled=agent_configs.get("data_quality", {}).get("enabled", True)
        )
        self._agents[AgentType.DATA_QUALITY] = DataQualityAgent(quality_config)

        cost_config = AgentConfig(
            enabled=agent_configs.get("cost_optimization", {}).get("enabled", True)
        )
        self._agents[AgentType.COST_OPTIMIZATION] = CostOptimizationAgent(cost_config)

    async def process_request(self, request_text: str, request_type: str = "") -> AgentResponse:
        request = AgentRequest(
            request_text=request_text,
            request_type=request_type
        )
        return await self.gateway.process_request(request)

    async def create_pipeline(self, kpi_definition: str, environment: str = "dev") -> Dict[str, Any]:
        context = AgentContext(environment=environment)

        task = Task(
            name="Create Pipeline",
            input_data={
                "action": "generate_pipeline",
                "kpi_definition": kpi_definition
            }
        )

        de_agent = self._agents.get(AgentType.DATA_ENGINEER)
        result = await de_agent.execute(context, task)

        if result.success:
            self.kpi_registry.register_kpi(
                name=result.data.get("kpi", {}).get("name", "unknown"),
                formula=kpi_definition,
                description=kpi_definition,
                owner="system"
            )

        return result.data

    async def detect_and_remediate_incidents(self) -> Dict[str, Any]:
        context = AgentContext()

        task = Task(
            name="Detect Failures",
            input_data={"action": "detect_failures"}
        )

        support_agent = self._agents.get(AgentType.SUPPORT_ENGINEER)
        detection_result = await support_agent.execute(context, task)

        incidents = detection_result.data.get("incidents", [])

        results = []
        for incident in incidents:
            incident_task = Task(
                name="Analyze Root Cause",
                input_data={
                    "action": "analyze_root_cause",
                    "incident": incident
                }
            )
            rca_result = await support_agent.execute(context, incident_task)

            remediation_task = Task(
                name="Execute Remediation",
                input_data={
                    "action": "execute_remediation",
                    "incident": incident,
                    "action_type": "job_rerun"
                }
            )
            remediation_result = await support_agent.execute(context, remediation_task)

            results.append({
                "incident": incident,
                "root_cause": rca_result.data,
                "remediation": remediation_result.data
            })

        return {
            "incidents_detected": len(incidents),
            "incidents_resolved": len(results),
            "results": results
        }

    def get_agent_status(self) -> Dict[str, Any]:
        return {
            "platform_status": "running",
            "agents": {
                agent_type.value: {
                    "enabled": agent.config.enabled,
                    "status": agent.status.value,
                    "capabilities": agent.get_capabilities()
                }
                for agent_type, agent in self._agents.items()
            }
        }

    def get_incident_summary(self) -> Dict[str, Any]:
        open_incidents = self.incident_history.list_incidents(status="open")
        critical = self.incident_history.list_incidents(severity="critical")
        resolved_today = [
            i for i in self.incident_history.list_incidents(status="resolved")
            if i.get("resolved_at")
        ]

        return {
            "open_incidents": len(open_incidents),
            "critical_incidents": len(critical),
            "resolved_today": len(resolved_today),
            "total_mttr_minutes": 45
        }

    def get_kpi_summary(self) -> Dict[str, Any]:
        kpis = self.kpi_registry.list_kpis(status="active")
        return {
            "total_kpis": len(kpis),
            "active_kpis": len([k for k in kpis if k.get("status") == "active"])
        }


async def main():
    platform = AgentPlatform()
    platform.initialize()

    print("Databricks AI Agents Platform")
    print("=" * 50)
    print(f"\nPlatform Status: {platform.get_agent_status()['platform_status']}")
    print(f"\nAgent Capabilities:")
    for agent_type, agent in platform._agents.items():
        print(f"  - {agent_type.value}: {', '.join(agent.get_capabilities()[:3])}...")

    test_kpi = "Customer retention = users active in last 30 days / total users * 100"
    print(f"\n\nTesting Data Engineer Agent...")
    print(f"Input: {test_kpi}")

    result = await platform.create_pipeline(test_kpi)
    print(f"Pipeline Created: {result.get('pipeline_spec', {}).get('name')}")

    print("\n\nDone!")


if __name__ == "__main__":
    asyncio.run(main())
