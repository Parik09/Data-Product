from typing import Any, Dict, List, Set, Optional
import re

from .base import (
    AgentConfig,
    AgentType,
    AgentContext,
    ExecutionResult,
    BaseAgent,
    Task,
)


class ReviewerAgent(BaseAgent):
    def __init__(self, config: AgentConfig):
        super().__init__(config, AgentType.REVIEWER)
        self._governance_rules = [
            "block_pii_exposure",
            "enforce_naming_conventions",
            "validate_schema_compatibility",
            "check_query_efficiency"
        ]
        self._approval_required_for_prod = True
        self._pii_patterns = self._load_pii_patterns()

    def get_capabilities(self) -> List[str]:
        return [
            "sql_validation",
            "governance_compliance",
            "pii_exposure_detection",
            "schema_compatibility_check",
            "query_efficiency_analysis",
            "approval_workflow",
        ]

    def get_config(self) -> Dict[str, Any]:
        return {
            "governance_rules": self._governance_rules,
            "approval_required_for_prod": self._approval_required_for_prod,
            "pii_patterns": list(self._pii_patterns.keys())
        }

    async def execute(self, context: AgentContext, task: Task) -> ExecutionResult:
        action = task.input_data.get("action", "review_pipeline")

        if action == "review_pipeline":
            return await self.review_pipeline(task)
        elif action == "review_sql":
            return await self.review_sql(task)
        elif action == "review_remediation":
            return await self.review_remediation(task)
        else:
            return ExecutionResult(
                success=False,
                error=f"Unknown action: {action}"
            )

    async def review_pipeline(self, task: Task) -> ExecutionResult:
        pipeline_spec = task.input_data.get("pipeline_spec", {})

        sql_review = await self._review_sql_efficiency(pipeline_spec)

        governance_result = await self._check_governance_compliance(pipeline_spec)

        pii_result = await self._check_pii_exposure(pipeline_spec)

        schema_result = await self._check_schema_compatibility(pipeline_spec)

        all_passed = (
            sql_review["passed"] and
            governance_result["passed"] and
            pii_result["passed"] and
            schema_result["passed"]
        )

        review_result = {
            "passed": all_passed,
            "sql_efficiency": sql_review,
            "governance_compliance": governance_result,
            "pii_exposure": pii_result,
            "schema_compatibility": schema_result,
            "warnings": [],
            "blocking_issues": []
        }

        if not sql_review["passed"]:
            review_result["blocking_issues"].extend(sql_review["issues"])
        if not governance_result["passed"]:
            review_result["blocking_issues"].extend(governance_result["issues"])
        if not pii_result["passed"]:
            review_result["blocking_issues"].extend(pii_result["issues"])
        if not schema_result["passed"]:
            review_result["blocking_issues"].extend(schema_result["issues"])

        review_result["warnings"] = sql_review.get("warnings", []) + \
                                     governance_result.get("warnings", []) + \
                                     pii_result.get("warnings", [])

        return ExecutionResult(
            success=True,
            data=review_result,
            metadata={"action": "review_pipeline"}
        )

    async def review_sql(self, task: Task) -> ExecutionResult:
        sql = task.input_data.get("sql", "")

        efficiency = await self._analyze_query_efficiency(sql)

        pii = await self._scan_for_pii(sql)

        naming = await self._check_naming_conventions(sql)

        return ExecutionResult(
            success=True,
            data={
                "efficiency": efficiency,
                "pii_exposure": pii,
                "naming_conventions": naming
            },
            metadata={"action": "review_sql"}
        )

    async def review_remediation(self, task: Task) -> ExecutionResult:
        remediation_action = task.input_data.get("action_type", "")
        incident_data = task.input_data.get("incident", {})

        allowed_actions = ["job_rerun", "cluster_restart", "sql_patch"]
        blocked_actions = ["schema_deletion", "data_deletion", "permission_change"]

        if remediation_action in blocked_actions:
            return ExecutionResult(
                success=False,
                data={
                    "approved": False,
                    "reason": f"Action {remediation_action} is blocked for safety",
                    "suggested_alternatives": allowed_actions
                }
            )

        risk_level = self._assess_remediation_risk(remediation_action, incident_data)

        return ExecutionResult(
            success=True,
            data={
                "approved": risk_level in ["low", "medium"],
                "risk_level": risk_level,
                "action_type": remediation_action,
                "requires_approval": risk_level == "high"
            }
        )

    def _load_pii_patterns(self) -> Dict[str, str]:
        return {
            "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
            "phone": r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
            "credit_card": r'\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b',
            "ip_address": r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',
        }

    async def _review_sql_efficiency(self, pipeline_spec: Dict[str, Any]) -> Dict[str, Any]:
        transformations = pipeline_spec.get("transformations", [])

        issues = []
        warnings = []

        for idx, sql in enumerate(transformations):
            if re.search(r'SELECT\s+\*', sql, re.IGNORECASE):
                warnings.append(f"Transformation {idx + 1}: Avoid SELECT *")

            if re.search(r'WHERE.*LIKE\s+[\'"]%', sql, re.IGNORECASE):
                issues.append(f"Transformation {idx + 1}: Leading wildcard in LIKE clause")

            if not re.search(r'WHERE', sql, re.IGNORECASE) and re.search(r'SELECT', sql, re.IGNORECASE):
                warnings.append(f"Transformation {idx + 1}: No WHERE clause - full table scan")

            if re.search(r'CROSS\s+JOIN', sql, re.IGNORECASE):
                issues.append(f"Transformation {idx + 1}: CROSS JOIN detected - potential performance issue")

            if re.search(r'DISTINCT', sql, re.IGNORECASE):
                warnings.append(f"Transformation {idx + 1}: DISTINCT may impact performance")

        return {
            "passed": len(issues) == 0,
            "issues": issues,
            "warnings": warnings,
            "score": max(0, 100 - len(issues) * 20 - len(warnings) * 5)
        }

    async def _check_governance_compliance(self, pipeline_spec: Dict[str, Any]) -> Dict[str, Any]:
        issues = []
        warnings = []

        target_table = pipeline_spec.get("target_table", "")
        if not target_table.startswith(("staging_", "analytics_", "metrics_")):
            warnings.append("Target table should follow naming conventions")

        properties = pipeline_spec.get("properties", {})
        if not properties.get("owner"):
            warnings.append("No owner specified in pipeline properties")

        return {
            "passed": len(issues) == 0,
            "issues": issues,
            "warnings": warnings
        }

    async def _check_pii_exposure(self, pipeline_spec: Dict[str, Any]) -> Dict[str, Any]:
        transformations = pipeline_spec.get("transformations", [])
        
        detected_pii = []

        for idx, sql in enumerate(transformations):
            for pii_type, pattern in self._pii_patterns.items():
                if re.search(pattern, sql, re.IGNORECASE):
                    detected_pii.append({
                        "type": pii_type,
                        "transformation_index": idx,
                        "action": "mask_required"
                    })

        return {
            "passed": len(detected_pii) == 0,
            "issues": [f"PII detected: {p['type']}" for p in detected_pii] if detected_pii else [],
            "warnings": ["Consider masking sensitive columns"] if not detected_pii else [],
            "detected_pii": detected_pii
        }

    async def _check_schema_compatibility(self, pipeline_spec: Dict[str, Any]) -> Dict[str, Any]:
        source_datasets = pipeline_spec.get("source_datasets", [])

        issues = []
        warnings = []

        if not source_datasets:
            issues.append("No source datasets specified")

        return {
            "passed": len(issues) == 0,
            "issues": issues,
            "warnings": warnings
        }

    async def _analyze_query_efficiency(self, sql: str) -> Dict[str, Any]:
        score = 100
        issues = []

        if "SELECT *" in sql.upper():
            score -= 20
            issues.append("Avoid SELECT *")

        if re.search(r'WHERE.*OR.', sql, re.IGNORECASE):
            score -= 15
            issues.append("OR in WHERE clause may impact performance")

        if "CROSS JOIN" in sql.upper():
            score -= 30
            issues.append("CROSS JOIN detected")

        if not re.search(r'WHERE', sql, re.IGNORECASE):
            score -= 10
            issues.append("No WHERE clause - full table scan")

        return {
            "score": max(0, score),
            "issues": issues,
            "recommendations": self._get_optimization_recommendations(sql)
        }

    async def _scan_for_pii(self, sql: str) -> Dict[str, Any]:
        detected = []
        for pii_type, pattern in self._pii_patterns.items():
            if re.search(pattern, sql, re.IGNORECASE):
                detected.append(pii_type)

        return {
            "detected": detected,
            "requires_masking": len(detected) > 0,
            "columns_to_mask": detected
        }

    async def _check_naming_conventions(self, sql: str) -> Dict[str, Any]:
        table_pattern = r'FROM\s+([a-zA-Z0-9_\.]+)|JOIN\s+([a-zA-Z0-9_\.]+)'
        tables = re.findall(table_pattern, sql, re.IGNORECASE)

        non_compliant = []
        for t in tables:
            table_name = t[0] or t[1]
            if not re.match(r'^[a-z][a-z0-9_]*$', table_name.split('.')[-1].lower()):
                non_compliant.append(table_name)

        return {
            "compliant": len(non_compliant) == 0,
            "non_compliant_tables": non_compliant
        }

    def _assess_remediation_risk(self, action_type: str, incident_data: Dict[str, Any]) -> str:
        risk_map = {
            "job_rerun": "low",
            "cluster_restart": "medium",
            "sql_patch": "medium",
            "schema_deletion": "high",
            "data_deletion": "high"
        }
        return risk_map.get(action_type, "medium")

    def _get_optimization_recommendations(self, sql: str) -> List[str]:
        recommendations = []

        if "SELECT *" in sql.upper():
            recommendations.append("Specify only required columns")
        if "CROSS JOIN" in sql.upper():
            recommendations.append("Use INNER JOIN with explicit conditions")
        if not re.search(r'WHERE', sql, re.IGNORECASE):
            recommendations.append("Add WHERE clause to filter data")

        return recommendations
