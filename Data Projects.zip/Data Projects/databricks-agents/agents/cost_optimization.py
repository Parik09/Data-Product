from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from .base import (
    AgentConfig,
    AgentType,
    AgentContext,
    ExecutionResult,
    BaseAgent,
    Task,
)


@dataclass
class ClusterMetrics:
    cluster_id: str
    cluster_name: str
    instance_type: str
    utilization_percent: float
    idle_time_minutes: float
    cost_per_hour: float
    total_cost: float
    status: str


@dataclass
class JobMetrics:
    job_id: str
    job_name: str
    runtime_minutes: float
    runs_per_day: float
    avg_execution_time_minutes: float
    total_cost: float
    status: str


@dataclass
class CostRecommendation:
    id: str
    category: str
    title: str
    description: str
    estimated_savings_monthly_usd: float
    effort: str
    risk: str
    actionable: bool = True


class CostOptimizationAgent(BaseAgent):
    def __init__(self, config: AgentConfig):
        super().__init__(config, AgentType.COST_OPTIMIZATION)
        self._idle_cluster_threshold = 30
        self._underutilized_threshold = 20
        self._alert_daily_cost = 100

    def get_capabilities(self) -> List[str]:
        return [
            "cluster_utilization_analysis",
            "job_runtime_analysis",
            "idle_compute_detection",
            "storage_growth_analysis",
            "cost_recommendations",
            "spending_alerts",
        ]

    async def execute(self, context: AgentContext, task: Task) -> ExecutionResult:
        action = task.input_data.get("action", "analyze_costs")

        if action == "analyze_costs":
            return await self.analyze_costs(task)
        elif action == "get_recommendations":
            return await self.get_recommendations(task)
        elif action == "estimate_cost":
            return await self.estimate_pipeline_cost(task)
        elif action == "set_alert":
            return await self.set_cost_alert(task)
        else:
            return ExecutionResult(
                success=False,
                error=f"Unknown action: {action}"
            )

    async def analyze_costs(self, task: Task) -> ExecutionResult:
        period = task.input_data.get("period", "7d")

        cluster_costs = await self._analyze_cluster_costs()

        job_costs = await self._analyze_job_costs()

        storage_costs = await self._analyze_storage_costs()

        total_cost = sum(c["total_cost"] for c in cluster_costs) + \
                     sum(j["total_cost"] for j in job_costs) + \
                     storage_costs["total_cost"]

        analysis = {
            "period": period,
            "total_cost_usd": total_cost,
            "breakdown": {
                "clusters": cluster_costs,
                "jobs": job_costs,
                "storage": storage_costs
            },
            "alerts": self._generate_cost_alerts(total_cost, cluster_costs),
            "recommendations": []
        }

        if total_cost > self._alert_daily_cost * 7:
            analysis["recommendations"] = await self._generate_recommendations(
                cluster_costs, job_costs, storage_costs
            )

        return ExecutionResult(
            success=True,
            data=analysis,
            metadata={"action": "analyze_costs", "period": period}
        )

    async def get_recommendations(self, task: Task) -> ExecutionResult:
        recommendations = []

        idle_clusters = await self._find_idle_clusters()
        for cluster in idle_clusters:
            recommendations.append(CostRecommendation(
                id=f"rec_{len(recommendations)}",
                category="compute",
                title=f"Terminate idle cluster: {cluster['cluster_name']}",
                description=f"Cluster has been idle for {cluster['idle_time_minutes']:.0f} minutes",
                estimated_savings_monthly_usd=cluster["estimated_monthly_savings"],
                effort="low",
                risk="low"
            ))

        underutilized = await self._find_underutilized_clusters()
        for cluster in underutilized:
            recommendations.append(CostRecommendation(
                id=f"rec_{len(recommendations)}",
                category="compute",
                title=f"Downsize cluster: {cluster['cluster_name']}",
                description=f"Cluster utilization is {cluster['utilization_percent']:.1f}%",
                estimated_savings_monthly_usd=cluster["estimated_monthly_savings"],
                effort="medium",
                risk="medium"
            ))

        expensive_jobs = await self._find_expensive_jobs()
        for job in expensive_jobs:
            recommendations.append(CostRecommendation(
                id=f"rec_{len(recommendations)}",
                category="jobs",
                title=f"Optimize job: {job['job_name']}",
                description=f"Job runs {job['runs_per_day']:.1f}x daily with {job['avg_execution_time_minutes']:.1f} min avg runtime",
                estimated_savings_monthly_usd=job["estimated_monthly_savings"],
                effort="medium",
                risk="low"
            ))

        old_data = await self._find_old_unused_data()
        for item in old_data:
            recommendations.append(CostRecommendation(
                id=f"rec_{len(recommendations)}",
                category="storage",
                title=f"Archive or delete: {item['table_name']}",
                description=f"Table not accessed in {item['days_since_access']} days, size: {item['size_gb']:.1f} GB",
                estimated_savings_monthly_usd=item["estimated_monthly_savings"],
                effort="low",
                risk="medium"
            ))

        total_potential_savings = sum(r.estimated_savings_monthly_usd for r in recommendations)

        return ExecutionResult(
            success=True,
            data={
                "recommendations": [self._recommendation_to_dict(r) for r in recommendations],
                "total_recommendations": len(recommendations),
                "potential_monthly_savings_usd": total_potential_savings,
                "by_category": self._group_by_category(recommendations)
            },
            metadata={"action": "get_recommendations"}
        )

    async def estimate_pipeline_cost(self, task: Task) -> ExecutionResult:
        pipeline_spec = task.input_data.get("pipeline_spec", {})

        num_tasks = len(pipeline_spec.get("transformations", []))
        estimated_runtime_hours = num_tasks * 0.1

        instance_type = pipeline_spec.get("instance_type", "i3.xlarge")
        hourly_rate = self._get_instance_price(instance_type)

        daily_runs = pipeline_spec.get("daily_runs", 1)

        daily_cost = estimated_runtime_hours * hourly_rate * daily_runs
        monthly_cost = daily_cost * 30

        return ExecutionResult(
            success=True,
            data={
                "estimated_runtime_hours": estimated_runtime_hours,
                "hourly_rate": hourly_rate,
                "daily_runs": daily_runs,
                "daily_cost_usd": daily_cost,
                "monthly_cost_usd": monthly_cost,
                "yearly_cost_usd": monthly_cost * 12
            },
            metadata={"action": "estimate_cost"}
        )

    async def set_cost_alert(self, task: Task) -> ExecutionResult:
        threshold = task.input_data.get("threshold_usd", 100)
        alert_type = task.input_data.get("type", "daily")

        return ExecutionResult(
            success=True,
            data={
                "alert_configured": True,
                "threshold_usd": threshold,
                "alert_type": alert_type,
                "message": f"Cost alert set: ${threshold}/day"
            },
            metadata={"action": "set_alert"}
        )

    async def _analyze_cluster_costs(self) -> List[Dict[str, Any]]:
        return [
            {
                "cluster_id": "cluster-001",
                "cluster_name": "etl-prod-cluster",
                "instance_type": "i3.xlarge",
                "utilization_percent": 65,
                "idle_time_minutes": 120,
                "cost_per_hour": 0.35,
                "total_cost": 58.5
            },
            {
                "cluster_id": "cluster-002",
                "cluster_name": "analytics-cluster",
                "instance_type": "i3.2xlarge",
                "utilization_percent": 15,
                "idle_time_minutes": 450,
                "cost_per_hour": 0.70,
                "total_cost": 42.0
            }
        ]

    async def _analyze_job_costs(self) -> List[Dict[str, Any]]:
        return [
            {
                "job_id": "job-001",
                "job_name": "daily_etl_pipeline",
                "runtime_minutes": 45,
                "runs_per_day": 1,
                "avg_execution_time_minutes": 45,
                "total_cost": 26.25
            },
            {
                "job_id": "job-002",
                "job_name": "hourly_data_sync",
                "runtime_minutes": 15,
                "runs_per_day": 24,
                "avg_execution_time_minutes": 15,
                "total_cost": 105.0
            }
        ]

    async def _analyze_storage_costs(self) -> Dict[str, Any]:
        return {
            "total_cost": 45.0,
            "total_tb": 2.5,
            "cost_per_tb": 18.0
        }

    async def _find_idle_clusters(self) -> List[Dict[str, Any]]:
        return [
            {
                "cluster_id": "cluster-002",
                "cluster_name": "analytics-cluster",
                "idle_time_minutes": 450,
                "estimated_monthly_savings": 315.0
            }
        ]

    async def _find_underutilized_clusters(self) -> List[Dict[str, Any]]:
        return [
            {
                "cluster_id": "cluster-002",
                "cluster_name": "analytics-cluster",
                "utilization_percent": 15,
                "estimated_monthly_savings": 157.5
            }
        ]

    async def _find_expensive_jobs(self) -> List[Dict[str, Any]]:
        return [
            {
                "job_id": "job-002",
                "job_name": "hourly_data_sync",
                "runs_per_day": 24,
                "avg_execution_time_minutes": 15,
                "estimated_monthly_savings": 52.5
            }
        ]

    async def _find_old_unused_data(self) -> List[Dict[str, Any]]:
        return [
            {
                "table_name": "staging.old_data_archive",
                "size_gb": 150,
                "days_since_access": 90,
                "estimated_monthly_savings": 67.5
            }
        ]

    async def _generate_recommendations(
        self,
        cluster_costs: List[Dict],
        job_costs: List[Dict],
        storage_costs: Dict
    ) -> List[Dict[str, Any]]:
        recommendations = []

        idle_clusters = [c for c in cluster_costs if c["idle_time_minutes"] > self._idle_cluster_threshold]
        for cluster in idle_clusters:
            recommendations.append({
                "category": "compute",
                "title": f"Terminate idle cluster: {cluster['cluster_name']}",
                "savings": cluster["total_cost"] * 30
            })

        underutilized = [c for c in cluster_costs if c["utilization_percent"] < self._underutilized_threshold]
        for cluster in underutilized:
            recommendations.append({
                "category": "compute",
                "title": f"Downsize cluster: {cluster['cluster_name']}",
                "savings": cluster["total_cost"] * 0.4
            })

        return recommendations

    def _generate_cost_alerts(
        self,
        total_cost: float,
        cluster_costs: List[Dict]
    ) -> List[Dict[str, Any]]:
        alerts = []

        if total_cost > self._alert_daily_cost * 7:
            alerts.append({
                "severity": "high",
                "message": f"Weekly cost (${total_cost:.2f}) exceeds threshold (${self._alert_daily_cost * 7})"
            })

        for cluster in cluster_costs:
            if cluster["idle_time_minutes"] > self._idle_cluster_threshold:
                alerts.append({
                    "severity": "medium",
                    "message": f"Cluster {cluster['cluster_name']} idle for {cluster['idle_time_minutes']:.0f} minutes"
                })

            if cluster["utilization_percent"] < self._underutilized_threshold:
                alerts.append({
                    "severity": "low",
                    "message": f"Cluster {cluster['cluster_name']} underutilized at {cluster['utilization_percent']:.1f}%"
                })

        return alerts

    def _get_instance_price(self, instance_type: str) -> float:
        prices = {
            "i3.xlarge": 0.35,
            "i3.2xlarge": 0.70,
            "i3.4xlarge": 1.40,
            "i3.8xlarge": 2.80,
            "r3.xlarge": 0.25,
            "r3.2xlarge": 0.50
        }
        return prices.get(instance_type, 0.35)

    def _recommendation_to_dict(self, rec: CostRecommendation) -> Dict[str, Any]:
        return {
            "id": rec.id,
            "category": rec.category,
            "title": rec.title,
            "description": rec.description,
            "estimated_savings_monthly_usd": rec.estimated_savings_monthly_usd,
            "effort": rec.effort,
            "risk": rec.risk,
            "actionable": rec.actionable
        }

    def _group_by_category(self, recommendations: List[CostRecommendation]) -> Dict[str, int]:
        grouped = {}
        for rec in recommendations:
            grouped[rec.category] = grouped.get(rec.category, 0) + 1
        return grouped
