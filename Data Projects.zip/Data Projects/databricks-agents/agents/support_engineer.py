from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
import asyncio

from .base import (
    AgentConfig,
    AgentType,
    AgentContext,
    ExecutionResult,
    BaseAgent,
    Severity,
    Task,
)


@dataclass
class Incident:
    id: str
    type: str
    severity: Severity
    source: str
    message: str
    timestamp: datetime
    job_id: Optional[str] = None
    task_id: Optional[str] = None
    cluster_id: Optional[str] = None
    run_id: Optional[str] = None
    error_details: Optional[str] = None
    affected_tables: List[str] = field(default_factory=list)
    affected_dashboards: List[str] = field(default_factory=list)
    downstream_impact: Dict[str, Any] = field(default_factory=dict)
    root_cause: Optional[str] = None
    recommended_actions: List[str] = field(default_factory=list)
    remediation_status: str = "pending"


@dataclass
class RemediationAction:
    type: str
    description: str
    target: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    status: str = "pending"
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


class SupportEngineerAgent(BaseAgent):
    def __init__(self, config: AgentConfig):
        super().__init__(config, AgentType.SUPPORT_ENGINEER)
        self._detection_interval = 300
        self._allowed_actions = ["job_rerun", "cluster_restart", "sql_patch"]
        self._blocked_actions = ["schema_deletion"]
        self._sla_breach_threshold = 5

    def get_capabilities(self) -> List[str]:
        return [
            "failure_detection",
            "root_cause_analysis",
            "downstream_impact_analysis",
            "automated_remediation",
            "job_rerun",
            "cluster_restart",
            "sql_patch_suggestion",
        ]

    async def execute(self, context: AgentContext, task: Task) -> ExecutionResult:
        action = task.input_data.get("action", "detect_failures")

        if action == "detect_failures":
            return await self.detect_failures(task)
        elif action == "analyze_root_cause":
            return await self.analyze_root_cause(task)
        elif action == "analyze_downstream_impact":
            return await self.analyze_downstream_impact(task)
        elif action == "execute_remediation":
            return await self.execute_remediation(task)
        else:
            return ExecutionResult(
                success=False,
                error=f"Unknown action: {action}"
            )

    async def detect_failures(self, task: Task) -> ExecutionResult:
        incidents = []

        job_failures = await self._check_job_failures()
        incidents.extend(job_failures)

        task_retries = await self._check_task_retries()
        incidents.extend(task_retries)

        sla_breaches = await self._check_sla_breaches()
        incidents.extend(sla_breaches)

        freshness_violations = await self._check_freshness_violations()
        incidents.extend(freshness_violations)

        return ExecutionResult(
            success=True,
            data={
                "incidents": [self._incident_to_dict(i) for i in incidents],
                "total_incidents": len(incidents),
                "critical_count": len([i for i in incidents if i.severity == Severity.CRITICAL]),
                "high_count": len([i for i in incidents if i.severity == Severity.HIGH])
            },
            metadata={"action": "detect_failures"}
        )

    async def analyze_root_cause(self, task: Task) -> ExecutionResult:
        incident_data = task.input_data.get("incident", {})
        incident_id = incident_data.get("id")

        logs = await self._parse_execution_logs(incident_id)

        failure_type = self._classify_failure_type(logs)

        recommended_actions = self._get_recommended_actions(failure_type)

        root_cause_analysis = {
            "incident_id": incident_id,
            "failure_type": failure_type,
            "logs_analyzed": len(logs),
            "root_cause": self._determine_root_cause(failure_type, logs),
            "recommended_actions": recommended_actions,
            "confidence_score": 0.87
        }

        return ExecutionResult(
            success=True,
            data=root_cause_analysis,
            metadata={"action": "analyze_root_cause"}
        )

    async def analyze_downstream_impact(self, task: Task) -> ExecutionResult:
        incident_data = task.input_data.get("incident", {})
        affected_tables = incident_data.get("affected_tables", [])

        lineage_data = await self._get_lineage_metadata(affected_tables)

        affected_dashboards = await self._identify_affected_dashboards(lineage_data)

        affected_applications = await self._identify_affected_applications(lineage_data)

        impact_analysis = {
            "incident_id": incident_data.get("id"),
            "affected_tables": affected_tables,
            "affected_dashboards": affected_dashboards,
            "affected_applications": affected_applications,
            "lineage_depth": 3,
            "total_affected_assets": len(affected_tables) + len(affected_dashboards) + len(affected_applications),
            "estimated_recovery_time_minutes": self._estimate_recovery_time(affected_tables)
        }

        return ExecutionResult(
            success=True,
            data=impact_analysis,
            metadata={"action": "analyze_downstream_impact"}
        )

    async def execute_remediation(self, task: Task) -> ExecutionResult:
        incident_data = task.input_data.get("incident", {})
        action_type = task.input_data.get("action_type", "job_rerun")

        if action_type in self._blocked_actions:
            return ExecutionResult(
                success=False,
                error=f"Action {action_type} is blocked for safety"
            )

        if action_type not in self._allowed_actions:
            return ExecutionResult(
                success=False,
                error=f"Action {action_type} is not in allowed actions"
            )

        remediation_result = await self._execute_action(
            action_type,
            incident_data
        )

        return ExecutionResult(
            success=remediation_result.get("success", False),
            data=remediation_result,
            metadata={"action": "execute_remediation", "action_type": action_type}
        )

    async def _check_job_failures(self) -> List[Incident]:
        return []

    async def _check_task_retries(self) -> List[Incident]:
        return []

    async def _check_sla_breaches(self) -> List[Incident]:
        return []

    async def _check_freshness_violations(self) -> List[Incident]:
        return []

    async def _parse_execution_logs(self, incident_id: str) -> List[Dict[str, Any]]:
        return []

    def _classify_failure_type(self, logs: List[Dict[str, Any]]) -> str:
        error_messages = [log.get("message", "") for log in logs]

        for msg in error_messages:
            if "OutOfMemory" in msg or "OOM" in msg:
                return "resource_exhaustion"
            if "Connection" in msg or "timeout" in msg.lower():
                return "connection_failure"
            if "permission" in msg.lower() or "denied" in msg.lower():
                return "permission_error"
            if "schema" in msg.lower() and "mismatch" in msg.lower():
                return "schema_mismatch"
            if "null" in msg.lower() or "None" in msg:
                return "null_pointer"

        return "unknown"

    def _determine_root_cause(self, failure_type: str, logs: List[Dict[str, Any]]) -> str:
        root_causes = {
            "resource_exhaustion": "Insufficient cluster memory allocation. Consider scaling up cluster size or optimizing query.",
            "connection_failure": "Network connectivity issue or external service timeout. Check source system availability.",
            "permission_error": "Insufficient permissions to access resource. Verify Unity Catalog ACLs.",
            "schema_mismatch": "Source schema has changed. Update target schema or add schema evolution.",
            "null_pointer": "Unexpected null value in data. Add null handling in transformation logic.",
            "unknown": "Unable to determine root cause. Manual investigation required."
        }
        return root_causes.get(failure_type, root_causes["unknown"])

    def _get_recommended_actions(self, failure_type: str) -> List[str]:
        actions_map = {
            "resource_exhaustion": [
                "Restart cluster with larger instance type",
                "Optimize query with better partitioning",
                "Enable auto-scaling"
            ],
            "connection_failure": [
                "Retry job run",
                "Check external system status",
                "Verify network connectivity"
            ],
            "permission_error": [
                "Request required permissions via Unity Catalog",
                "Verify service principal credentials"
            ],
            "schema_mismatch": [
                "Enable schema evolution",
                "Update target schema",
                "Review source schema changes"
            ],
            "null_pointer": [
                "Add null handling in SQL",
                "Implement default values",
                "Add data quality checks"
            ],
            "unknown": [
                "Manual investigation required",
                "Review full error logs"
            ]
        }
        return actions_map.get(failure_type, [])

    async def _get_lineage_metadata(self, tables: List[str]) -> Dict[str, Any]:
        return {"tables": tables, "lineage": []}

    async def _identify_affected_dashboards(self, lineage_data: Dict[str, Any]) -> List[str]:
        return []

    async def _identify_affected_applications(self, lineage_data: Dict[str, Any]) -> List[str]:
        return []

    def _estimate_recovery_time(self, affected_tables: List[str]) -> int:
        base_time = 15
        return base_time + (len(affected_tables) * 5)

    async def _execute_action(self, action_type: str, incident_data: Dict[str, Any]) -> Dict[str, Any]:
        if action_type == "job_rerun":
            return await self._rerun_job(incident_data)
        elif action_type == "cluster_restart":
            return await self._restart_cluster(incident_data)
        elif action_type == "sql_patch":
            return await self._apply_sql_patch(incident_data)
        return {"success": False, "error": "Unknown action type"}

    async def _rerun_job(self, incident_data: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "success": True,
            "action": "job_rerun",
            "job_id": incident_data.get("job_id"),
            "new_run_id": f"new_run_{datetime.utcnow().timestamp()}",
            "message": "Job successfully rerun"
        }

    async def _restart_cluster(self, incident_data: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "success": True,
            "action": "cluster_restart",
            "cluster_id": incident_data.get("cluster_id"),
            "message": "Cluster restarted successfully"
        }

    async def _apply_sql_patch(self, incident_data: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "success": True,
            "action": "sql_patch",
            "suggested_sql": "SELECT * FROM table WHERE column IS NOT NULL",
            "message": "SQL patch generated and ready for review"
        }

    def _incident_to_dict(self, incident: Incident) -> Dict[str, Any]:
        return {
            "id": incident.id,
            "type": incident.type,
            "severity": incident.severity.value,
            "source": incident.source,
            "message": incident.message,
            "timestamp": incident.timestamp.isoformat(),
            "job_id": incident.job_id,
            "task_id": incident.task_id,
            "cluster_id": incident.cluster_id,
            "remediation_status": incident.remediation_status
        }
