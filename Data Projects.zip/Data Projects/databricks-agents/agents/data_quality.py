from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from .base import (
    AgentConfig,
    AgentType,
    AgentContext,
    ExecutionResult,
    BaseAgent,
    Task,
    Severity,
)


@dataclass
class QualityCheck:
    id: str
    name: str
    check_type: str
    table_name: str
    column_name: Optional[str]
    expression: str
    threshold: Optional[float] = None
    status: str = "pending"
    last_run: Optional[datetime] = None
    result: Optional[Dict[str, Any]] = None


@dataclass
class QualityAlert:
    id: str
    check_id: str
    severity: Severity
    message: str
    timestamp: datetime
    table_name: str
    column_name: Optional[str]
    actual_value: Any
    threshold: Any
    acknowledged: bool = False


class DataQualityAgent(BaseAgent):
    def __init__(self, config: AgentConfig):
        super().__init__(config, AgentType.DATA_QUALITY)
        self._alert_threshold = 0.95
        self._quality_checks: Dict[str, QualityCheck] = {}

    def get_capabilities(self) -> List[str]:
        return [
            "row_count_anomaly_detection",
            "null_spike_detection",
            "schema_drift_detection",
            "freshness_sla_monitoring",
            "quality_alerting",
            "trend_analysis",
        ]

    async def execute(self, context: AgentContext, task: Task) -> ExecutionResult:
        action = task.input_data.get("action", "run_checks")

        if action == "run_checks":
            return await self.run_quality_checks(task)
        elif action == "analyze_results":
            return await self.analyze_results(task)
        elif action == "configure_quality":
            return await self.configure_quality_checks(task)
        elif action == "generate_report":
            return await self.generate_quality_report(task)
        else:
            return ExecutionResult(
                success=False,
                error=f"Unknown action: {action}"
            )

    async def run_quality_checks(self, task: Task) -> ExecutionResult:
        tables = task.input_data.get("tables", [])

        results = []

        for table in tables:
            row_count_result = await self._check_row_count(table)
            results.append(row_count_result)

            null_results = await self._check_null_spikes(table)
            results.extend(null_results)

            schema_result = await self._check_schema_drift(table)
            results.append(schema_result)

            freshness_result = await self._check_freshness(table)
            results.append(freshness_result)

        passed = len([r for r in results if r.get("passed", False)])
        failed = len([r for r in results if not r.get("passed", True)])

        return ExecutionResult(
            success=True,
            data={
                "results": results,
                "summary": {
                    "total_checks": len(results),
                    "passed": passed,
                    "failed": failed,
                    "pass_rate": passed / len(results) if results else 1.0
                },
                "alerts": self._generate_alerts(results)
            },
            metadata={"action": "run_quality_checks"}
        )

    async def analyze_results(self, task: Task) -> ExecutionResult:
        results = task.input_data.get("results", [])

        trend_analysis = await self._analyze_trends(results)

        anomaly_patterns = self._detect_anomaly_patterns(results)

        recommendations = self._generate_recommendations(results)

        return ExecutionResult(
            success=True,
            data={
                "trend_analysis": trend_analysis,
                "anomaly_patterns": anomaly_patterns,
                "recommendations": recommendations
            },
            metadata={"action": "analyze_results"}
        )

    async def configure_quality_checks(self, task: Task) -> ExecutionResult:
        pipeline_spec = task.input_data.get("pipeline_spec", {})

        quality_checks = pipeline_spec.get("quality_checks", [])

        for check_config in quality_checks:
            check = QualityCheck(
                id=check_config.get("id", f"check_{len(self._quality_checks)}"),
                name=check_config.get("name", "quality_check"),
                check_type=check_config.get("type", "expression"),
                table_name=pipeline_spec.get("target_table", ""),
                column_name=check_config.get("column"),
                expression=check_config.get("expression", ""),
                threshold=check_config.get("threshold")
            )
            self._quality_checks[check.id] = check

        return ExecutionResult(
            success=True,
            data={
                "configured_checks": len(quality_checks),
                "checks": {k: {"name": v.name, "expression": v.expression} 
                          for k, v in self._quality_checks.items()}
            },
            metadata={"action": "configure_quality"}
        )

    async def generate_quality_report(self, task: Task) -> ExecutionResult:
        results = task.input_data.get("results", [])
        
        report = {
            "generated_at": datetime.utcnow().isoformat(),
            "summary": {
                "total_checks": len(results),
                "passed": len([r for r in results if r.get("passed")]),
                "failed": len([r for r in results if not r.get("passed")])
            },
            "failed_checks": [r for r in results if not r.get("passed")],
            "recommendations": self._generate_recommendations(results),
            "sla_compliance": await self._calculate_sla_compliance(results)
        }

        return ExecutionResult(
            success=True,
            data=report,
            metadata={"action": "generate_report"}
        )

    async def _check_row_count(self, table: str) -> Dict[str, Any]:
        baseline_count = await self._get_baseline_row_count(table)
        current_count = await self._get_current_row_count(table)

        if baseline_count is None:
            return {
                "check_type": "row_count",
                "table": table,
                "passed": True,
                "message": "Baseline established",
                "current_count": current_count
            }

        change_percent = abs((current_count - baseline_count) / baseline_count * 100) if baseline_count > 0 else 0

        passed = change_percent < 20

        return {
            "check_type": "row_count",
            "table": table,
            "passed": passed,
            "baseline": baseline_count,
            "current": current_count,
            "change_percent": change_percent,
            "threshold": 20,
            "message": f"Row count change: {change_percent:.1f}%"
        }

    async def _check_null_spikes(self, table: str) -> List[Dict[str, Any]]:
        results = []

        columns = await self._get_table_columns(table)

        for column in columns:
            baseline_null_rate = await self._get_baseline_null_rate(table, column["name"])
            current_null_rate = await self._get_current_null_rate(table, column["name"])

            if baseline_null_rate is None:
                continue

            spike_threshold = 0.1
            passed = (current_null_rate - baseline_null_rate) < spike_threshold

            results.append({
                "check_type": "null_spike",
                "table": table,
                "column": column["name"],
                "passed": passed,
                "baseline_null_rate": baseline_null_rate,
                "current_null_rate": current_null_rate,
                "spike": current_null_rate - baseline_null_rate,
                "threshold": spike_threshold,
                "message": f"Null rate change: {(current_null_rate - baseline_null_rate) * 100:.1f}%"
            })

        return results

    async def _check_schema_drift(self, table: str) -> Dict[str, Any]:
        expected_schema = await self._get_expected_schema(table)
        actual_schema = await self._get_actual_schema(table)

        added_columns = set(actual_schema.keys()) - set(expected_schema.keys())
        removed_columns = set(expected_schema.keys()) - set(actual_schema.keys())
        type_changes = []

        for col in set(expected_schema.keys()) & set(actual_schema.keys()):
            if expected_schema[col] != actual_schema[col]:
                type_changes.append({
                    "column": col,
                    "expected": expected_schema[col],
                    "actual": actual_schema[col]
                })

        passed = len(added_columns) == 0 and len(removed_columns) == 0 and len(type_changes) == 0

        return {
            "check_type": "schema_drift",
            "table": table,
            "passed": passed,
            "added_columns": list(added_columns),
            "removed_columns": list(removed_columns),
            "type_changes": type_changes,
            "message": f"Schema drift: {len(added_columns)} added, {len(removed_columns)} removed"
        }

    async def _check_freshness(self, table: str) -> Dict[str, Any]:
        last_updated = await self._get_last_update_time(table)
        
        if last_updated is None:
            return {
                "check_type": "freshness",
                "table": table,
                "passed": False,
                "message": "Unable to determine last update time"
            }

        max_age_minutes = 60
        age_minutes = (datetime.utcnow() - last_updated).total_seconds() / 60

        passed = age_minutes < max_age_minutes

        return {
            "check_type": "freshness",
            "table": table,
            "passed": passed,
            "last_updated": last_updated.isoformat(),
            "age_minutes": age_minutes,
            "threshold_minutes": max_age_minutes,
            "message": f"Table age: {age_minutes:.0f} minutes"
        }

    async def _get_baseline_row_count(self, table: str) -> Optional[int]:
        return None

    async def _get_current_row_count(self, table: str) -> int:
        return 10000

    async def _get_table_columns(self, table: str) -> List[Dict[str, str]]:
        return [{"name": "id", "type": "bigint"}, {"name": "value", "type": "string"}]

    async def _get_baseline_null_rate(self, table: str, column: str) -> Optional[float]:
        return 0.05

    async def _get_current_null_rate(self, table: str, column: str) -> float:
        return 0.06

    async def _get_expected_schema(self, table: str) -> Dict[str, str]:
        return {"id": "bigint", "value": "string"}

    async def _get_actual_schema(self, table: str) -> Dict[str, str]:
        return {"id": "bigint", "value": "string"}

    async def _get_last_update_time(self, table: str) -> Optional[datetime]:
        return datetime.utcnow() - timedelta(minutes=30)

    def _generate_alerts(self, results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        alerts = []

        for result in results:
            if not result.get("passed", True):
                alerts.append({
                    "severity": "high",
                    "table": result.get("table"),
                    "check_type": result.get("check_type"),
                    "message": result.get("message"),
                    "timestamp": datetime.utcnow().isoformat()
                })

        return alerts

    async def _analyze_trends(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        return {
            "trend_direction": "stable",
            "data_points": len(results),
            "confidence": 0.85
        }

    def _detect_anomaly_patterns(self, results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        patterns = []

        failed_checks = [r for r in results if not r.get("passed")]
        if len(failed_checks) > 3:
            patterns.append({
                "pattern": "multiple_failures",
                "severity": "high",
                "description": f"Multiple quality checks failed: {len(failed_checks)}"
            })

        return patterns

    def _generate_recommendations(self, results: List[Dict[str, Any]]) -> List[str]:
        recommendations = []

        failed_checks = [r for r in results if not r.get("passed")]

        for check in failed_checks:
            check_type = check.get("check_type")
            if check_type == "row_count":
                recommendations.append("Review data pipeline for data loss or duplication")
            elif check_type == "null_spike":
                recommendations.append("Investigate data source for null value increase")
            elif check_type == "schema_drift":
                recommendations.append("Update target schema or enable schema evolution")
            elif check_type == "freshness":
                recommendations.append("Check upstream pipeline scheduling")

        return recommendations

    async def _calculate_sla_compliance(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not results:
            return {"compliant": True, "score": 100}

        passed = len([r for r in results if r.get("passed")])
        score = (passed / len(results)) * 100

        return {
            "compliant": score >= (self._alert_threshold * 100),
            "score": score,
            "threshold": self._alert_threshold * 100
        }
