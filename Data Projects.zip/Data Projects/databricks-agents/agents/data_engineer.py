from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional
import re

from .base import (
    AgentConfig,
    AgentType,
    AgentContext,
    ExecutionResult,
    BaseAgent,
    Task,
)


@dataclass
class KPIDefinition:
    name: str
    formula: str
    description: str
    source_tables: List[str] = field(default_factory=list)
    dimensions: List[str] = field(default_factory=list)
    filters: List[str] = field(default_factory=list)
    aggregation: str = "count"
    time_window: Optional[str] = None


@dataclass
class PipelineSpec:
    id: str
    name: str
    kpi_definition: KPIDefinition
    source_datasets: List[str] = field(default_factory=list)
    transformations: List[str] = field(default_factory=list)
    target_table: str
    schedule: Optional[str] = None
    pipeline_language: str = "dlt"
    quality_checks: List[Dict[str, Any]] = field(default_factory=list)
    properties: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DeploymentResult:
    success: bool
    pipeline_id: Optional[str] = None
    pipeline_name: Optional[str] = None
    target_table: Optional[str] = None
    schedule: Optional[str] = None
    error: Optional[str] = None
    warnings: List[str] = field(default_factory=list)


class DataEngineerAgent(BaseAgent):
    def __init__(self, config: AgentConfig):
        super().__init__(config, AgentType.DATA_ENGINEER)
        self._default_language = "dlt"
        self._deployment_environments = ["dev", "qa", "prod"]
        self._auto_deploy = False
        self._max_generation_time = 120

    def get_capabilities(self) -> List[str]:
        return [
            "natural_language_kpi_intake",
            "metadata_discovery",
            "pipeline_generation",
            "dlt_creation",
            "workflow_scheduling",
            "auto_deployment",
        ]

    async def execute(self, context: AgentContext, task: Task) -> ExecutionResult:
        action = task.input_data.get("action", "generate_pipeline")

        if action == "generate_pipeline":
            return await self.generate_pipeline(task)
        elif action == "deploy_pipeline":
            return await self.deploy_pipeline(task)
        elif action == "discover_metadata":
            return await self.discover_metadata(task)
        else:
            return ExecutionResult(
                success=False,
                error=f"Unknown action: {action}"
            )

    async def generate_pipeline(self, task: Task) -> ExecutionResult:
        kpi_text = task.input_data.get("kpi_definition", "")
        
        kpi = self._parse_kpi_definition(kpi_text)

        candidate_datasets = await self._discover_candidate_datasets(kpi)

        pipeline_spec = await self._generate_pipeline_spec(kpi, candidate_datasets)

        return ExecutionResult(
            success=True,
            data={
                "pipeline_spec": self._pipeline_spec_to_dict(pipeline_spec),
                "kpi": self._kpi_to_dict(kpi),
                "candidate_datasets": candidate_datasets,
                "estimated_generation_time_seconds": 45
            },
            metadata={"action": "generate_pipeline"}
        )

    async def deploy_pipeline(self, task: Task) -> ExecutionResult:
        pipeline_spec_data = task.input_data.get("pipeline_spec", {})
        environment = task.input_data.get("environment", "dev")

        deployment_result = await self._create_dlt_pipeline(
            pipeline_spec_data,
            environment
        )

        if deployment_result.success and self._auto_deploy:
            await self._register_dataset(pipeline_spec_data)
            await self._schedule_refresh(pipeline_spec_data)

        return ExecutionResult(
            success=deployment_result.success,
            data=self._deployment_to_dict(deployment_result),
            metadata={"action": "deploy_pipeline", "environment": environment}
        )

    async def discover_metadata(self, task: Task) -> ExecutionResult:
        catalog = task.input_data.get("catalog", "main")
        schema_pattern = task.input_data.get("schema_pattern", "*")

        schemas = await self._query_unity_catalog_schemas(catalog, schema_pattern)

        tables = await self._query_unity_catalog_tables(catalog)

        lineage = await self._get_lineage_data()

        return ExecutionResult(
            success=True,
            data={
                "schemas": schemas,
                "tables": tables,
                "lineage": lineage
            },
            metadata={"action": "discover_metadata"}
        )

    def _parse_kpi_definition(self, kpi_text: str) -> KPIDefinition:
        kpi_text = kpi_text.strip()

        name_match = re.search(r'^(\w+)\s*=', kpi_text)
        name = name_match.group(1) if name_match else "kpi_" + str(datetime.utcnow().timestamp())

        if "=" in kpi_text:
            formula = kpi_text.split("=", 1)[1].strip()
        else:
            formula = kpi_text

        time_window = None
        time_patterns = [
            (r'last\s+(\d+)\s+days?', 'days'),
            (r'last\s+(\d+)\s+weeks?', 'weeks'),
            (r'last\s+(\d+)\s+months?', 'months'),
            (r'last\s+(\d+)\s+hours?', 'hours'),
            (r'last\s+(\d+)\s+minutes?', 'minutes'),
        ]
        for pattern, window in time_patterns:
            match = re.search(pattern, formula, re.IGNORECASE)
            if match:
                time_window = f"{match.group(1)} {window}"
                break

        aggregation = "count"
        agg_patterns = {
            r'\bcount\s*\(': "count",
            r'\bsum\s*\(': "sum",
            r'\bavg\s*\(': "avg",
            r'\bmax\s*\(': "max",
            r'\bmin\s*\(': "min",
            r'\bdistinct\s+count\s*\(': "distinct_count",
        }
        for pattern, agg in agg_patterns.items():
            if re.search(pattern, formula, re.IGNORECASE):
                aggregation = agg
                break

        table_pattern = r'from\s+(\w+(?:\.\w+)?(?:\.\w+)?)'
        tables = re.findall(table_pattern, formula, re.IGNORECASE)

        return KPIDefinition(
            name=name,
            formula=formula,
            description=kpi_text,
            source_tables=tables,
            time_window=time_window,
            aggregation=aggregation
        )

    async def _discover_candidate_datasets(self, kpi: KPIDefinition) -> List[Dict[str, Any]]:
        candidate_datasets = []

        for table in kpi.source_tables:
            dataset_info = {
                "table_name": table,
                "schema": self._get_schema_info(table),
                "relationships": self._find_relationships(table),
                "join_paths": self._find_join_paths(table),
                "relevance_score": 0.9
            }
            candidate_datasets.append(dataset_info)

        return candidate_datasets

    def _get_schema_info(self, table: str) -> Dict[str, Any]:
        return {
            "columns": [
                {"name": "id", "type": "bigint", "nullable": False},
                {"name": "created_at", "type": "timestamp", "nullable": True},
                {"name": "updated_at", "type": "timestamp", "nullable": True},
            ]
        }

    def _find_relationships(self, table: str) -> List[Dict[str, Any]]:
        return []

    def _find_join_paths(self, table: str) -> List[List[str]]:
        return []

    async def _generate_pipeline_spec(
        self,
        kpi: KPIDefinition,
        candidate_datasets: List[Dict[str, Any]]
    ) -> PipelineSpec:
        transformations = self._generate_transformations(kpi, candidate_datasets)

        quality_checks = self._generate_quality_checks(kpi)

        target_table = f"{kpi.name}_metrics"

        return PipelineSpec(
            id=f"pipeline_{kpi.name}_{int(datetime.utcnow().timestamp())}",
            name=f"kpi_{kpi.name}",
            kpi_definition=kpi,
            source_datasets=[ds["table_name"] for ds in candidate_datasets],
            transformations=transformations,
            target_table=target_table,
            schedule="0 6 * * *",
            pipeline_language=self._default_language,
            quality_checks=quality_checks,
            properties={
                "kpi_name": kpi.name,
                "kpi_formula": kpi.formula,
                "aggregation": kpi.aggregation,
                "time_window": kpi.time_window
            }
        )

    def _generate_transformations(
        self,
        kpi: KPIDefinition,
        datasets: List[Dict[str, Any]]
    ) -> List[str]:
        transformations = []

        source_tables = ", ".join(datasets[0].get("table_name", "source_table") for datasets if datasets)
        
        if kpi.aggregation == "count":
            agg_expr = f"COUNT(*) as {kpi.name}_count"
        elif kpi.aggregation == "distinct_count":
            agg_expr = f"COUNT(DISTINCT user_id) as {kpi.name}_distinct_count"
        elif kpi.aggregation == "sum":
            agg_expr = f"SUM(value) as {kpi.name}_sum"
        elif kpi.aggregation == "avg":
            agg_expr = f"AVG(value) as {kpi.name}_avg"
        else:
            agg_expr = f"COUNT(*) as {kpi.name}_count"

        transformation = f"""
SELECT 
    {agg_expr},
    CURRENT_DATE() as metric_date
FROM {source_tables}
WHERE {self._generate_time_filter(kpi.time_window)}
GROUP BY 1
"""
        transformations.append(transformation.strip())

        return transformations

    def _generate_time_filter(self, time_window: Optional[str]) -> str:
        if not time_window:
            return "1=1"

        match = re.match(r'(\d+)\s+(days?|weeks?|months?|hours?|minutes?)', time_window, re.IGNORECASE)
        if match:
            value, unit = match.groups()
            if unit.startswith('day'):
                return f"created_at >= DATE_SUB(CURRENT_DATE(), {value})"
            elif unit.startswith('week'):
                return f"created_at >= DATE_SUB(CURRENT_DATE(), {int(value) * 7})"
            elif unit.startswith('month'):
                return f"created_at >= ADD_MONTHS(CURRENT_DATE(), -{value})"
            elif unit.startswith('hour'):
                return f"created_at >= DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL {value} HOUR)"

        return "1=1"

    def _generate_quality_checks(self, kpi: KPIDefinition) -> List[Dict[str, Any]]:
        return [
            {
                "name": f"row_count_check_{kpi.name}",
                "expression": "row_count > 0",
                "action": "alert"
            },
            {
                "name": f"null_check_{kpi.name}",
                "expression": f"{kpi.name}_count IS NOT NULL",
                "action": "alert"
            },
            {
                "name": f"freshness_check_{kpi.name}",
                "expression": "metric_date >= DATE_SUB(CURRENT_DATE(), 1)",
                "action": "alert"
            }
        ]

    async def _create_dlt_pipeline(
        self,
        pipeline_spec: Dict[str, Any],
        environment: str
    ) -> DeploymentResult:
        return DeploymentResult(
            success=True,
            pipeline_id=f"pipeline_{datetime.utcnow().timestamp()}",
            pipeline_name=pipeline_spec.get("name", "kpi_pipeline"),
            target_table=pipeline_spec.get("target_table"),
            schedule=pipeline_spec.get("schedule")
        )

    async def _register_dataset(self, pipeline_spec: Dict[str, Any]) -> Dict[str, Any]:
        return {"success": True}

    async def _schedule_refresh(self, pipeline_spec: Dict[str, Any]) -> Dict[str, Any]:
        return {"success": True}

    async def _query_unity_catalog_schemas(self, catalog: str, pattern: str) -> List[Dict[str, Any]]:
        return [
            {"name": "analytics", "catalog": catalog},
            {"name": "staging", "catalog": catalog},
            {"name": "raw", "catalog": catalog}
        ]

    async def _query_unity_catalog_tables(self, catalog: str) -> List[Dict[str, Any]]:
        return []

    async def _get_lineage_data(self) -> Dict[str, Any]:
        return {"lineage": []}

    def _pipeline_spec_to_dict(self, spec: PipelineSpec) -> Dict[str, Any]:
        return {
            "id": spec.id,
            "name": spec.name,
            "source_datasets": spec.source_datasets,
            "transformations": spec.transformations,
            "target_table": spec.target_table,
            "schedule": spec.schedule,
            "pipeline_language": spec.pipeline_language,
            "quality_checks": spec.quality_checks,
            "properties": spec.properties
        }

    def _kpi_to_dict(self, kpi: KPIDefinition) -> Dict[str, Any]:
        return {
            "name": kpi.name,
            "formula": kpi.formula,
            "description": kpi.description,
            "source_tables": kpi.source_tables,
            "dimensions": kpi.dimensions,
            "filters": kpi.filters,
            "aggregation": kpi.aggregation,
            "time_window": kpi.time_window
        }

    def _deployment_to_dict(self, result: DeploymentResult) -> Dict[str, Any]:
        return {
            "success": result.success,
            "pipeline_id": result.pipeline_id,
            "pipeline_name": result.pipeline_name,
            "target_table": result.target_table,
            "schedule": result.schedule,
            "error": result.error,
            "warnings": result.warnings
        }
