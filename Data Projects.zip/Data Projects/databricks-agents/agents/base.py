from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
import uuid


class AgentType(Enum):
    SUPPORT_ENGINEER = "support_engineer"
    DATA_ENGINEER = "data_engineer"
    PLANNER = "planner"
    REVIEWER = "reviewer"
    DATA_QUALITY = "data_quality"
    COST_OPTIMIZATION = "cost_optimization"


class AgentStatus(Enum):
    IDLE = "idle"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    WAITING = "waiting"


class TaskStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"


class Severity(Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class AgentConfig:
    enabled: bool = True
    timeout_seconds: int = 300
    max_retries: int = 3
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Task:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    status: TaskStatus = TaskStatus.PENDING
    assigned_agent: Optional[AgentType] = None
    input_data: Dict[str, Any] = field(default_factory=dict)
    output_data: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error: Optional[str] = None
    dependencies: List[str] = field(default_factory=list)

    def start(self):
        self.status = TaskStatus.IN_PROGRESS
        self.started_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()

    def complete(self, output_data: Dict[str, Any]):
        self.status = TaskStatus.COMPLETED
        self.output_data = output_data
        self.completed_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()

    def fail(self, error: str):
        self.status = TaskStatus.FAILED
        self.error = error
        self.updated_at = datetime.utcnow()


@dataclass
class ExecutionResult:
    success: bool
    data: Any = None
    error: Optional[str] = None
    warnings: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    execution_time_seconds: float = 0.0
    agent_type: Optional[AgentType] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)


@dataclass
class AgentContext:
    request_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    environment: str = "dev"
    tasks: List[Task] = field(default_factory=list)
    global_context: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)


class BaseAgent(ABC):
    def __init__(self, config: AgentConfig, agent_type: AgentType):
        self.config = config
        self.agent_type = agent_type
        self.status = AgentStatus.IDLE
    
    @abstractmethod
    async def execute(self, context: AgentContext, task: Task) -> ExecutionResult:
        pass

    async def validate_input(self, task: Task) -> ExecutionResult:
        if not task.input_data:
            return ExecutionResult(
                success=False,
                error="No input data provided"
            )
        return ExecutionResult(success=True)

    async def pre_execute(self, context: AgentContext, task: Task) -> ExecutionResult:
        self.status = AgentStatus.RUNNING
        return await self.validate_input(task)

    async def post_execute(self, context: AgentContext, task: Task, result: ExecutionResult):
        self.status = AgentStatus.IDLE if result.success else AgentStatus.FAILED

    def get_capabilities(self) -> List[str]:
        return []

    def get_metadata(self) -> Dict[str, Any]:
        return {
            "agent_type": self.agent_type.value,
            "enabled": self.config.enabled,
            "capabilities": self.get_capabilities()
        }


class AgentRegistry:
    _agents: Dict[AgentType, BaseAgent] = {}

    @classmethod
    def register(cls, agent_type: AgentType, agent: BaseAgent):
        cls._agents[agent_type] = agent

    @classmethod
    def get(cls, agent_type: AgentType) -> Optional[BaseAgent]:
        return cls._agents.get(agent_type)

    @classmethod
    def get_all(cls) -> Dict[AgentType, BaseAgent]:
        return cls._agents.copy()

    @classmethod
    def clear(cls):
        cls._agents.clear()
