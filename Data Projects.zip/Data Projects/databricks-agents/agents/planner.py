from typing import Any, Dict, List, Optional
import re

from .base import (
    AgentConfig,
    AgentType,
    AgentContext,
    ExecutionResult,
    BaseAgent,
    Task,
    TaskStatus,
    AgentType,
)


class PlannerAgent(BaseAgent):
    def __init__(self, config: AgentConfig):
        super().__init__(config, AgentType.PLANNER)
        self._max_tasks = 50
        self._task_timeout = 300

    def get_capabilities(self) -> List[str]:
        return [
            "request_decomposition",
            "task_assignment",
            "execution_planning",
            "dependency_management",
        ]

    async def execute(self, context: AgentContext, task: Task) -> ExecutionResult:
        user_request = task.input_data.get("request", "")

        request_type = self._classify_request(user_request)

        if request_type == "pipeline_creation":
            return await self._plan_pipeline_creation(context, task)
        elif request_type == "incident_response":
            return await self._plan_incident_response(context, task)
        elif request_type == "data_quality":
            return await self._plan_data_quality_check(context, task)
        else:
            return await self._plan_generic(context, task)

    async def _plan_pipeline_creation(
        self,
        context: AgentContext,
        task: Task
    ) -> ExecutionResult:
        tasks = [
            Task(
                name="Parse KPI Definition",
                description="Extract KPI requirements from natural language",
                input_data=task.input_data,
                assigned_agent=AgentType.DATA_ENGINEER
            ),
            Task(
                name="Discover Metadata",
                description="Query Unity Catalog for candidate datasets",
                input_data={"action": "discover_metadata"},
                assigned_agent=AgentType.DATA_ENGINEER
            ),
            Task(
                name="Generate Pipeline Spec",
                description="Create SQL transformations and DLT pipeline",
                input_data={"action": "generate_pipeline"},
                assigned_agent=AgentType.DATA_ENGINEER
            ),
            Task(
                name="Review Pipeline",
                description="Validate SQL, governance, and PII exposure",
                input_data={"action": "review_pipeline"},
                assigned_agent=AgentType.REVIEWER
            ),
            Task(
                name="Deploy Pipeline",
                description="Create and schedule pipeline in target environment",
                input_data={"action": "deploy_pipeline"},
                assigned_agent=AgentType.DATA_ENGINEER,
                dependencies=["Review Pipeline"]
            ),
            Task(
                name="Configure Data Quality",
                description="Set up quality checks and monitoring",
                input_data={"action": "configure_quality"},
                assigned_agent=AgentType.DATA_QUALITY,
                dependencies=["Deploy Pipeline"]
            )
        ]

        execution_plan = {
            "request_type": "pipeline_creation",
            "total_tasks": len(tasks),
            "estimated_duration_minutes": 10,
            "tasks": [self._task_to_dict(t) for t in tasks],
            "parallel_tasks": ["Parse KPI Definition", "Discover Metadata"],
            "sequential_flow": ["Generate Pipeline Spec", "Review Pipeline", "Deploy Pipeline", "Configure Data Quality"]
        }

        context.tasks = tasks

        return ExecutionResult(
            success=True,
            data=execution_plan,
            metadata={"action": "plan_pipeline_creation", "task_count": len(tasks)}
        )

    async def _plan_incident_response(
        self,
        context: AgentContext,
        task: Task
    ) -> ExecutionResult:
        tasks = [
            Task(
                name="Detect Failures",
                description="Monitor for job failures and anomalies",
                input_data={"action": "detect_failures"},
                assigned_agent=AgentType.SUPPORT_ENGINEER
            ),
            Task(
                name="Analyze Root Cause",
                description="Parse logs and determine failure type",
                input_data={"action": "analyze_root_cause"},
                assigned_agent=AgentType.SUPPORT_ENGINEER
            ),
            Task(
                name="Analyze Downstream Impact",
                description="Identify affected tables and dashboards",
                input_data={"action": "analyze_downstream_impact"},
                assigned_agent=AgentType.SUPPORT_ENGINEER
            ),
            Task(
                name="Review Remediation",
                description="Validate proposed remediation actions",
                input_data={"action": "review_remediation"},
                assigned_agent=AgentType.REVIEWER
            ),
            Task(
                name="Execute Remediation",
                description="Perform automated remediation if approved",
                input_data={"action": "execute_remediation"},
                assigned_agent=AgentType.SUPPORT_ENGINEER,
                dependencies=["Review Remediation"]
            ),
            Task(
                name="Verify Resolution",
                description="Confirm incident is resolved",
                input_data={"action": "verify_resolution"},
                assigned_agent=AgentType.SUPPORT_ENGINEER,
                dependencies=["Execute Remediation"]
            )
        ]

        execution_plan = {
            "request_type": "incident_response",
            "total_tasks": len(tasks),
            "estimated_duration_minutes": 5,
            "tasks": [self._task_to_dict(t) for t in tasks]
        }

        context.tasks = tasks

        return ExecutionResult(
            success=True,
            data=execution_plan,
            metadata={"action": "plan_incident_response"}
        )

    async def _plan_data_quality_check(
        self,
        context: AgentContext,
        task: Task
    ) -> ExecutionResult:
        tasks = [
            Task(
                name="Run Quality Checks",
                description="Execute data quality validation",
                input_data={"action": "run_checks"},
                assigned_agent=AgentType.DATA_QUALITY
            ),
            Task(
                name="Analyze Results",
                description="Process quality metrics and anomalies",
                input_data={"action": "analyze_results"},
                assigned_agent=AgentType.DATA_QUALITY
            ),
            Task(
                name="Generate Report",
                description="Create quality report with recommendations",
                input_data={"action": "generate_report"},
                assigned_agent=AgentType.DATA_QUALITY
            )
        ]

        execution_plan = {
            "request_type": "data_quality",
            "total_tasks": len(tasks),
            "tasks": [self._task_to_dict(t) for t in tasks]
        }

        return ExecutionResult(
            success=True,
            data=execution_plan,
            metadata={"action": "plan_data_quality"}
        )

    async def _plan_generic(
        self,
        context: AgentContext,
        task: Task
    ) -> ExecutionResult:
        return ExecutionResult(
            success=True,
            data={
                "request_type": "generic",
                "tasks": [self._task_to_dict(task)],
                "message": "Generic task created"
            }
        )

    def _classify_request(self, request: str) -> str:
        request_lower = request.lower()

        pipeline_keywords = ["pipeline", "kpi", "create", "build", "generate", "metric"]
        if any(kw in request_lower for kw in pipeline_keywords):
            return "pipeline_creation"

        incident_keywords = ["fail", "error", "incident", "issue", "problem", "broken"]
        if any(kw in request_lower for kw in incident_keywords):
            return "incident_response"

        quality_keywords = ["quality", "check", "validate", "test", "monitor"]
        if any(kw in request_lower for kw in quality_keywords):
            return "data_quality"

        return "generic"

    def _task_to_dict(self, task: Task) -> Dict[str, Any]:
        return {
            "id": task.id,
            "name": task.name,
            "description": task.description,
            "status": task.status.value,
            "assigned_agent": task.assigned_agent.value if task.assigned_agent else None,
            "dependencies": task.dependencies,
            "created_at": task.created_at.isoformat()
        }
