from datetime import datetime, timedelta
import random
import uuid


def generate_synthetic_incidents(count: int = 50):
    incidents = []
    incident_types = [
        "job_failure",
        "task_retry",
        "sla_breach",
        "data_freshness_violation",
        "schema_drift",
        "cluster_failure",
        "permission_error",
        "resource_exhaustion"
    ]
    severities = ["critical", "high", "medium", "low"]
    sources = ["system_tables", "monitoring", "lineage", "quality_checks"]

    for i in range(count):
        incident = {
            "id": f"inc_{uuid.uuid4().hex[:8]}",
            "type": random.choice(incident_types),
            "severity": random.choice(severities),
            "source": random.choice(sources),
            "message": f"Detected {random.choice(incident_types).replace('_', ' ')} in pipeline",
            "timestamp": (datetime.utcnow() - timedelta(hours=random.randint(0, 168))).isoformat(),
            "job_id": f"job_{random.randint(1000, 9999)}",
            "task_id": f"task_{random.randint(100, 999)}",
            "cluster_id": f"cluster-{random.randint(1, 20)}",
            "run_id": f"run_{random.randint(100000, 999999)}",
            "error_details": f"Error code: {random.randint(1000, 9999)}",
            "affected_tables": [f"analytics.table_{random.randint(1, 10)}" for _ in range(random.randint(1, 3))],
            "affected_dashboards": [f"dashboard_{random.randint(1, 5)}" for _ in range(random.randint(0, 2))],
            "status": random.choice(["open", "investigating", "resolved", "closed"]),
            "root_cause": random.choice(["Network timeout", "Schema mismatch", "Out of memory", "Permission denied", None]),
            "remediation_action": random.choice(["job_rerun", "cluster_restart", "sql_patch", None]),
            "resolved_at": (datetime.utcnow() - timedelta(hours=random.randint(1, 48))).isoformat() if random.random() > 0.5 else None
        }
        incidents.append(incident)
    return incidents


def generate_synthetic_kpis(count: int = 30):
    kpis = []
    kpi_templates = [
        {"name": "customer_retention", "formula": "active_users_30d / total_users * 100", "category": "growth"},
        {"name": "revenue_per_user", "formula": "total_revenue / active_users", "category": "revenue"},
        {"name": "daily_active_users", "formula": "COUNT(DISTINCT user_id) WHERE date = today()", "category": "engagement"},
        {"name": "conversion_rate", "formula": "conversions / total_visits * 100", "category": "conversion"},
        {"name": "churn_rate", "formula": "churned_users / total_users_at_start * 100", "category": "retention"},
        {"name": "avg_order_value", "formula": "total_revenue / total_orders", "category": "revenue"},
        {"name": "cart_abandonment_rate", "formula": "abandoned_carts / initiated_carts * 100", "category": "conversion"},
        {"name": "support_ticket_resolution_time", "formula": "AVG(resolution_timestamp - created_timestamp)", "category": "support"},
        {"name": "data_quality_score", "formula": "(valid_records / total_records) * 100", "category": "quality"},
        {"name": "pipeline_success_rate", "formula": "successful_runs / total_runs * 100", "category": "operations"}
    ]

    for i in range(count):
        template = random.choice(kpi_templates)
        kpi = {
            "id": f"kpi_{uuid.uuid4().hex[:8]}",
            "name": template["name"],
            "formula": template["formula"],
            "description": f"KPI measuring {template['category']} for {template['name']}",
            "category": template["category"],
            "owner": random.choice(["data_team", "analytics_team", "business_team"]),
            "status": random.choice(["active", "active", "active", "deprecated"]),
            "target_value": round(random.uniform(50, 100), 2),
            "current_value": round(random.uniform(40, 95), 2),
            "source_tables": [f"raw.table_{random.randint(1, 20)}" for _ in range(random.randint(1, 3))],
            "refresh_frequency": random.choice(["hourly", "daily", "weekly"]),
            "created_at": (datetime.utcnow() - timedelta(days=random.randint(30, 365))).isoformat(),
            "updated_at": (datetime.utcnow() - timedelta(days=random.randint(0, 30))).isoformat()
        }
        kpis.append(kpi)
    return kpis


def generate_synthetic_pipelines(count: int = 20):
    pipelines = []
    pipeline_types = ["dlt", "job", "streaming"]

    for i in range(count):
        pipeline = {
            "id": f"pipeline_{uuid.uuid4().hex[:8]}",
            "name": f"etl_{random.choice(['customer', 'product', 'order', 'inventory', 'analytics'])}_{random.randint(1, 10)}",
            "type": random.choice(pipeline_types),
            "status": random.choice(["running", "running", "running", "stopped", "failed"]),
            "target_table": f"analytics.{random.choice(['fact_', 'dim_'])}{random.choice(['customer', 'product', 'order'])}",
            "source_tables": [f"raw.table_{random.randint(1, 20)}" for _ in range(random.randint(1, 4))],
            "transformations": random.randint(2, 8),
            "quality_checks": random.randint(1, 5),
            "last_run": (datetime.utcnow() - timedelta(minutes=random.randint(0, 1440))).isoformat(),
            "last_run_duration_seconds": random.randint(60, 3600),
            "last_run_status": random.choice(["success", "success", "success", "failed"]),
            "next_scheduled_run": (datetime.utcnow() + timedelta(hours=random.randint(1, 24))).isoformat(),
            "schedule": random.choice(["0 * * * *", "0 6 * * *", "0 0 * * *"]),
            "cluster_type": random.choice(["interactive", "job", "serverless"]),
            "cost_per_run_usd": round(random.uniform(0.5, 25.0), 2)
        }
        pipelines.append(pipeline)
    return pipelines


def generate_synthetic_clusters(count: int = 15):
    clusters = []
    instance_types = ["i3.xlarge", "i3.2xlarge", "i3.4xlarge", "r3.xlarge", "r3.2xlarge"]

    for i in range(count):
        cluster = {
            "id": f"cluster-{random.randint(1, 50)}",
            "name": f"{random.choice(['etl', 'analytics', 'ml', 'ad-hoc'])}_cluster_{random.randint(1, 10)}",
            "instance_type": random.choice(instance_types),
            "num_workers": random.choice([2, 4, 8, 16, 32]),
            "status": random.choice(["running", "running", "terminated", "terminated"]),
            "utilization_percent": round(random.uniform(5, 95), 1),
            "idle_time_minutes": random.randint(0, 480) if random.random() > 0.5 else 0,
            "uptime_hours": random.randint(1, 720),
            "cost_per_hour": round(random.uniform(0.25, 3.0), 2),
            "total_cost_7d": round(random.uniform(50, 500), 2),
            "created_at": (datetime.utcnow() - timedelta(days=random.randint(1, 180))).isoformat()
        }
        clusters.append(cluster)
    return clusters


def generate_synthetic_quality_checks(count: int = 100):
    checks = []
    check_types = ["row_count", "null_check", "schema_validation", "freshness", "uniqueness", "range_check"]
    tables = [f"analytics.{random.choice(['fact_', 'dim_'])}{random.choice(['customer', 'product', 'order', 'inventory'])}" for _ in range(10)]

    for i in range(count):
        check = {
            "id": f"qc_{uuid.uuid4().hex[:8]}",
            "name": f"{random.choice(check_types)}_{random.randint(1, 100)}",
            "type": random.choice(check_types),
            "table": random.choice(tables),
            "column": f"col_{random.randint(1, 20)}" if random.random() > 0.3 else None,
            "status": random.choice(["passed", "passed", "passed", "failed", "warning"]),
            "threshold": round(random.uniform(0.8, 1.0), 2),
            "actual_value": round(random.uniform(0.75, 1.0), 2),
            "last_checked": (datetime.utcnow() - timedelta(minutes=random.randint(0, 1440))).isoformat(),
            "failures_24h": random.randint(0, 10)
        }
        checks.append(check)
    return checks


def generate_synthetic_jobs(count: int = 50):
    jobs = []
    job_types = ["scheduled", "continuous", "adhoc"]

    for i in range(count):
        job = {
            "id": f"job_{random.randint(1000, 9999)}",
            "name": f"{random.choice(['daily', 'hourly', 'weekly', 'realtime'])}_{random.choice(['etl', 'sync', 'aggregation', 'reporting'])}_{random.choice(['customer', 'product', 'order', 'inventory'])}",
            "type": random.choice(job_types),
            "status": random.choice(["running", "idle", "failed"]),
            "schedule": random.choice(["0 * * * *", "0 6 * * *", "0 0 * * *", None]),
            "last_run": (datetime.utcnow() - timedelta(hours=random.randint(0, 168))).isoformat(),
            "last_run_duration_minutes": round(random.uniform(1, 120), 1),
            "last_run_status": random.choice(["success", "success", "success", "failed", "cancelled"]),
            "next_run": (datetime.utcnow() + timedelta(hours=random.randint(1, 72))).isoformat() if random.random() > 0.3 else None,
            "runs_per_day": random.randint(1, 24),
            "avg_duration_minutes": round(random.uniform(5, 90), 1),
            "cost_per_day_usd": round(random.uniform(5, 150), 2)
        }
        jobs.append(job)
    return jobs


def generate_synthetic_lineage():
    return {
        "nodes": [
            {"id": "raw.customer_raw", "name": "customer_raw", "type": "table", "layer": "raw"},
            {"id": "raw.order_raw", "name": "order_raw", "type": "table", "layer": "raw"},
            {"id": "raw.product_raw", "name": "product_raw", "type": "table", "layer": "raw"},
            {"id": "staging.customer_stg", "name": "customer_stg", "type": "table", "layer": "staging"},
            {"id": "staging.order_stg", "name": "order_stg", "type": "table", "layer": "staging"},
            {"id": "analytics.dim_customer", "name": "dim_customer", "type": "table", "layer": "analytics"},
            {"id": "analytics.fact_orders", "name": "fact_orders", "type": "table", "layer": "analytics"},
            {"id": "analytics.kpi_revenue", "name": "kpi_revenue", "type": "view", "layer": "analytics"},
            {"id": "dashboard.revenue", "name": "revenue_dashboard", "type": "dashboard", "layer": "consumption"}
        ],
        "edges": [
            {"source": "raw.customer_raw", "target": "staging.customer_stg", "type": "transform"},
            {"source": "raw.order_raw", "target": "staging.order_stg", "type": "transform"},
            {"source": "raw.product_raw", "target": "staging.customer_stg", "type": "transform"},
            {"source": "staging.customer_stg", "target": "analytics.dim_customer", "type": "transform"},
            {"source": "staging.order_stg", "target": "analytics.fact_orders", "type": "transform"},
            {"source": "analytics.dim_customer", "target": "analytics.kpi_revenue", "type": "transform"},
            {"source": "analytics.fact_orders", "target": "analytics.kpi_revenue", "type": "transform"},
            {"source": "analytics.kpi_revenue", "target": "dashboard.revenue", "type": "reads"}
        ]
    }


SYNTHETIC_INCIDENTS = generate_synthetic_incidents()
SYNTHETIC_KPIS = generate_synthetic_kpis()
SYNTHETIC_PIPELINES = generate_synthetic_pipelines()
SYNTHETIC_CLUSTERS = generate_synthetic_clusters()
SYNTHETIC_QUALITY_CHECKS = generate_synthetic_quality_checks()
SYNTHETIC_JOBS = generate_synthetic_jobs()
SYNTHETIC_LINEAGE = generate_synthetic_lineage()


def get_synthetic_data(data_type: str):
    data_map = {
        "incidents": SYNTHETIC_INCIDENTS,
        "kpis": SYNTHETIC_KPIS,
        "pipelines": SYNTHETIC_PIPELINES,
        "clusters": SYNTHETIC_CLUSTERS,
        "quality_checks": SYNTHETIC_QUALITY_CHECKS,
        "jobs": SYNTHETIC_JOBS,
        "lineage": SYNTHETIC_LINEAGE
    }
    return data_map.get(data_type, [])
