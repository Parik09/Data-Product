from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime
import uuid

from ..agents.base import (
    AgentType,
    AgentConfig,
    AgentContext,
    Task,
    TaskStatus,
    ExecutionResult,
)


@dataclass
class AgentRequest:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    user_id: Optional[str] = None
    request_text: str = ""
    request_type: str = ""
    priority: int = 1
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class AgentResponse:
    request_id: str
    success: bool
    data: Any = None
    error: Optional[str] = None
    execution_time_seconds: float = 0.0
    tasks: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    completed_at: datetime = field(default_factory=datetime.utcnow)


class AgentGateway:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.agents = {}
        self._initialize_agents()

    def _initialize_agents(self):
        from ..agents import (
            SupportEngineerAgent,
            DataEngineerAgent,
            PlannerAgent,
            ReviewerAgent,
            DataQualityAgent,
            CostOptimizationAgent,
        )

        support_config = AgentConfig(
            enabled=self.config.get("agents", {}).get("support_engineer", {}).get("enabled", True),
            timeout_seconds=300
        )
        self.agents[AgentType.SUPPORT_ENGINEER] = SupportEngineerAgent(support_config)

        de_config = AgentConfig(
            enabled=self.config.get("agents", {}).get("data_engineer", {}).get("enabled", True),
            timeout_seconds=300
        )
        self.agents[AgentType.DATA_ENGINEER] = DataEngineerAgent(de_config)

        planner_config = AgentConfig(
            enabled=self.config.get("agents", {}).get("planner", {}).get("enabled", True),
            timeout_seconds=300
        )
        self.agents[AgentType.PLANNER] = PlannerAgent(planner_config)

        reviewer_config = AgentConfig(
            enabled=self.config.get("agents", {}).get("reviewer", {}).get("enabled", True),
            timeout_seconds=300
        )
        self.agents[AgentType.REVIEWER] = ReviewerAgent(reviewer_config)

        quality_config = AgentConfig(
            enabled=self.config.get("agents", {}).get("data_quality", {}).get("enabled", True),
            timeout_seconds=300
        )
        self.agents[AgentType.DATA_QUALITY] = DataQualityAgent(quality_config)

        cost_config = AgentConfig(
            enabled=self.config.get("agents", {}).get("cost_optimization", {}).get("enabled", True),
            timeout_seconds=300
        )
        self.agents[AgentType.COST_OPTIMIZATION] = CostOptimizationAgent(cost_config)

    def get_agent(self, agent_type: AgentType):
        return self.agents.get(agent_type)

    def list_agents(self) -> List[Dict[str, Any]]:
        return [
            {
                "type": agent_type.value,
                "enabled": agent.config.enabled,
                "capabilities": agent.get_capabilities()
            }
            for agent_type, agent in self.agents.items()
        ]

    async def process_request(self, request: AgentRequest) -> AgentResponse:
        context = AgentContext(
            request_id=request.id,
            user_id=request.user_id,
            environment=self.config.get("environment", "dev")
        )

        task = Task(
            name="Process Request",
            description=request.request_text,
            input_data={
                "request": request.request_text,
                "request_type": request.request_type,
                "metadata": request.metadata
            }
        )

        planner = self.agents.get(AgentType.PLANNER)
        if not planner:
            return AgentResponse(
                request_id=request.id,
                success=False,
                error="Planner agent not available"
            )

        plan_result = await planner.execute(context, task)

        if not plan_result.success:
            return AgentResponse(
                request_id=request.id,
                success=False,
                error=plan_result.error
            )

        execution_plan = plan_result.data
        context.tasks = [
            Task(
                name=t.get("name"),
                description=t.get("description"),
                assigned_agent=AgentType(t.get("assigned_agent")) if t.get("assigned_agent") else None,
                input_data=task.input_data
            )
            for t in execution_plan.get("tasks", [])
        ]

        orchestrator = AgentOrchestrator(self.agents)
        execution_result = await orchestrator.execute_plan(context, execution_plan)

        return AgentResponse(
            request_id=request.id,
            success=execution_result.success,
            data=execution_result.data,
            error=execution_result.error,
            execution_time_seconds=execution_result.execution_time_seconds,
            tasks=[{"name": t.name, "status": t.status.value} for t in context.tasks],
            metadata=execution_plan
        )


class AgentOrchestrator:
    def __init__(self, agents: Dict[AgentType, Any]):
        self.agents = agents

    async def execute_plan(self, context: AgentContext, execution_plan: Dict[str, Any]) -> ExecutionResult:
        tasks = execution_plan.get("tasks", [])

        completed_tasks = {}
        results = []

        for task_data in tasks:
            task = Task(
                id=task_data.get("id", str(uuid.uuid4())),
                name=task_data.get("name"),
                description=task_data.get("description"),
                assigned_agent=AgentType(task_data["assigned_agent"]) if task_data.get("assigned_agent") else None,
                dependencies=task_data.get("dependencies", [])
            )

            for dep in task.dependencies:
                if dep not in completed_tasks:
                    task.status = TaskStatus.BLOCKED
                    break

            if task.status == TaskStatus.BLOCKED:
                results.append({"task": task.name, "status": "blocked"})
                continue

            task.start()

            if not task.assigned_agent:
                task.complete({"message": "No agent assigned"})
                completed_tasks[task.name] = task
                results.append({"task": task.name, "status": "skipped"})
                continue

            agent = self.agents.get(task.assigned_agent)
            if not agent:
                task.fail(f"Agent {task.assigned_agent} not found")
                results.append({"task": task.name, "status": "failed", "error": task.error})
                continue

            try:
                result = await agent.execute(context, task)
                if result.success:
                    task.complete(result.data)
                    completed_tasks[task.name] = task
                else:
                    task.fail(result.error or "Unknown error")
                results.append({
                    "task": task.name,
                    "status": task.status.value,
                    "result": result.data if result.success else None,
                    "error": result.error
                })
            except Exception as e:
                task.fail(str(e))
                results.append({"task": task.name, "status": "failed", "error": str(e)})

        all_completed = all(
            t.status in [TaskStatus.COMPLETED, TaskStatus.BLOCKED]
            for t in context.tasks
        )

        failed_count = len([r for r in results if r.get("status") == "failed"])

        return ExecutionResult(
            success=all_completed and failed_count == 0,
            data={
                "execution_plan": execution_plan.get("request_type"),
                "total_tasks": len(tasks),
                "completed_tasks": len([t for t in completed_tasks.values() if t.status == TaskStatus.COMPLETED]),
                "failed_tasks": failed_count,
                "results": results
            },
            error=None if all_completed else f"{failed_count} tasks failed"
        )
