from typing import Any, Dict, List, Optional
import asyncio
import json
from datetime import datetime
from collections import deque


class TaskQueue:
    def __init__(self, max_size: int = 1000):
        self._queue = deque(maxlen=max_size)
        self._processing = {}
        self._completed = {}
        self._lock = asyncio.Lock()

    async def enqueue(self, task: Dict[str, Any]) -> str:
        async with self._lock:
            task_id = task.get("id", str(id(task)))
            task["status"] = "pending"
            task["queued_at"] = datetime.utcnow().isoformat()
            self._queue.append(task)
            return task_id

    async def dequeue(self) -> Optional[Dict[str, Any]]:
        async with self._lock:
            if self._queue:
                task = self._queue.popleft()
                task["status"] = "processing"
                task["started_at"] = datetime.utcnow().isoformat()
                self._processing[task["id"]] = task
                return task
            return None

    async def complete(self, task_id: str, result: Any):
        async with self._lock:
            if task_id in self._processing:
                task = self._processing.pop(task_id)
                task["status"] = "completed"
                task["completed_at"] = datetime.utcnow().isoformat()
                task["result"] = result
                self._completed[task_id] = task

    async def fail(self, task_id: str, error: str):
        async with self._lock:
            if task_id in self._processing:
                task = self._processing.pop(task_id)
                task["status"] = "failed"
                task["completed_at"] = datetime.utcnow().isoformat()
                task["error"] = error
                self._completed[task_id] = task

    async def get_status(self, task_id: str) -> Optional[Dict[str, Any]]:
        async with self._lock:
            if task_id in self._processing:
                return self._processing[task_id]
            if task_id in self._completed:
                return self._completed[task_id]
            for task in self._queue:
                if task["id"] == task_id:
                    return task
            return None

    async def get_queue_status(self) -> Dict[str, Any]:
        async with self._lock:
            return {
                "pending": len(self._queue),
                "processing": len(self._processing),
                "completed": len(self._completed),
                "total": len(self._queue) + len(self._processing) + len(self._completed)
            }

    async def clear_completed(self, older_than_hours: int = 24):
        async with self._lock:
            cutoff = datetime.utcnow().timestamp() - (older_than_hours * 3600)
            to_remove = []
            for task_id, task in self._completed.items():
                completed_at = datetime.fromisoformat(task["completed_at"]).timestamp()
                if completed_at < cutoff:
                    to_remove.append(task_id)
            for task_id in to_remove:
                del self._completed[task_id]


class EventBus:
    def __init__(self):
        self._subscribers: Dict[str, List[callable]] = {}
        self._lock = asyncio.Lock()

    async def subscribe(self, event_type: str, callback: callable):
        async with self._lock:
            if event_type not in self._subscribers:
                self._subscribers[event_type] = []
            self._subscribers[event_type].append(callback)

    async def unsubscribe(self, event_type: str, callback: callable):
        async with self._lock:
            if event_type in self._subscribers:
                self._subscribers[event_type].remove(callback)

    async def publish(self, event_type: str, data: Dict[str, Any]):
        if event_type in self._subscribers:
            for callback in self._subscribers[event_type]:
                try:
                    await callback(data)
                except Exception as e:
                    pass


class MemoryStore:
    def __init__(self):
        self._storage: Dict[str, List[Dict[str, Any]]] = {
            "kpi_registry": [],
            "incident_history": [],
            "agent_memory": [],
            "semantic_model": []
        }

    async def store(self, table: str, data: Dict[str, Any]):
        if table not in self._storage:
            self._storage[table] = []
        data["stored_at"] = datetime.utcnow().isoformat()
        self._storage[table].append(data)

    async def query(self, table: str, filters: Optional[Dict[str, Any]] = None, limit: int = 100) -> List[Dict[str, Any]]:
        if table not in self._storage:
            return []

        results = self._storage[table]
        if filters:
            results = [
                r for r in results
                if all(r.get(k) == v for k, v in filters.items())
            ]
        return results[-limit:]

    async def get_recent(self, table: str, count: int = 10) -> List[Dict[str, Any]]:
        if table not in self._storage:
            return []
        return self._storage[table][-count:]

    async def update(self, table: str, record_id: str, updates: Dict[str, Any]) -> bool:
        if table not in self._storage:
            return False
        for record in self._storage[table]:
            if record.get("id") == record_id:
                record.update(updates)
                record["updated_at"] = datetime.utcnow().isoformat()
                return True
        return False

    async def delete(self, table: str, record_id: str) -> bool:
        if table not in self._storage:
            return False
        for i, record in enumerate(self._storage[table]):
            if record.get("id") == record_id:
                self._storage[table].pop(i)
                return True
        return False

    async def get_all_tables(self) -> List[str]:
        return list(self._storage.keys())
