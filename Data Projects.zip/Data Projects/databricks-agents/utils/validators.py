import logging
from typing import Any, Dict, List, Optional
from datetime import datetime


class AgentLogger:
    def __init__(self, name: str = "databricks_agents"):
        self.logger = logging.getLogger(name)
        self._setup_handlers()

    def _setup_handlers(self):
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)

    def log_agent_start(self, agent_type: str, task: str):
        self.logger.info(f"[{agent_type}] Starting task: {task}")

    def log_agent_complete(self, agent_type: str, task: str, duration: float):
        self.logger.info(f"[{agent_type}] Completed task: {task} in {duration:.2f}s")

    def log_agent_error(self, agent_type: str, task: str, error: str):
        self.logger.error(f"[{agent_type}] Error in task {task}: {error}")

    def log_decision(self, agent_type: str, decision: str, context: Dict[str, Any]):
        self.logger.info(f"[{agent_type}] Decision: {decision} | Context: {context}")

    def log_remediation(self, action: str, target: str, result: str):
        self.logger.info(f"[REMEDIATION] {action} on {target}: {result}")


class SQLValidator:
    BLOCKED_KEYWORDS = [
        "DROP DATABASE",
        "DROP SCHEMA",
        "TRUNCATE",
        "DELETE FROM",
        "GRANT",
        "REVOKE"
    ]

    DANGEROUS_PATTERNS = [
        r"\*\s*FROM\s+\w+\s*$",
        r"WHERE\s+1\s*=\s*1",
    ]

    @staticmethod
    def is_safe_sql(sql: str) -> Dict[str, Any]:
        sql_upper = sql.upper()

        for keyword in SQLValidator.BLOCKED_KEYWORDS:
            if keyword in sql_upper:
                return {
                    "safe": False,
                    "reason": f"Blocked keyword detected: {keyword}",
                    "severity": "high"
                }

        for pattern in SQLValidator.DANGEROUS_PATTERNS:
            import re
            if re.search(pattern, sql, re.IGNORECASE):
                return {
                    "safe": False,
                    "reason": f"Dangerous pattern detected: {pattern}",
                    "severity": "medium"
                }

        return {"safe": True, "reason": "SQL appears safe", "severity": "none"}

    @staticmethod
    def validate_naming(name: str, entity_type: str = "table") -> Dict[str, Any]:
        import re

        patterns = {
            "table": r'^[a-z][a-z0-9_]*$',
            "column": r'^[a-z][a-z0-9_]*$',
            "schema": r'^[a-z][a-z0-9_]*$',
            "catalog": r'^[a-z][a-z0-9_]*$'
        }

        pattern = patterns.get(entity_type, patterns["table"])

        if re.match(pattern, name):
            return {"valid": True, "message": "Name follows conventions"}
        else:
            return {
                "valid": False,
                "message": f"Name should match pattern: {pattern}",
                "suggested": name.lower().replace(" ", "_")
            }


class DataMasker:
    PII_PATTERNS = {
        "email": r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
        "ssn": r'\d{3}-\d{2}-\d{4}',
        "phone": r'\d{3}[-.]?\d{3}[-.]?\d{4}',
        "credit_card": r'\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}',
    }

    @classmethod
    def detect_pii(cls, data: str) -> List[str]:
        import re
        detected = []
        for pii_type, pattern in cls.PII_PATTERNS.items():
            if re.search(pattern, data):
                detected.append(pii_type)
        return detected

    @classmethod
    def mask_value(cls, value: str, pii_type: str) -> str:
        masks = {
            "email": lambda v: v[0] + "***" + v[v.index("@"):] if "@" in v else "***",
            "ssn": lambda v: "***-**-" + v[-4:] if len(v) >= 4 else "***-**-****",
            "phone": lambda v: "***-***-" + v[-4:] if len(v) >= 4 else "***-***-****",
            "credit_card": lambda v: "****-****-****-" + v[-4:] if len(v) >= 4 else "****-****-****-****",
        }
        mask_func = masks.get(pii_type, lambda v: "***")
        return mask_func(value)

    @classmethod
    def mask_data(cls, data: Dict[str, Any]) -> Dict[str, Any]:
        masked = data.copy()
        for key, value in masked.items():
            if isinstance(value, str):
                pii_types = cls.detect_pii(value)
                if pii_types:
                    for pii_type in pii_types:
                        masked[key] = cls.mask_value(masked[key], pii_type)
        return masked
