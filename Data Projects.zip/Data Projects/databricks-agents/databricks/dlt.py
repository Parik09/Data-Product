from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class PipelineConfig:
    name: str
    target: str
    notebooks: List[str] = field(default_factory=list)
    sql_streams: List[str] = field(default_factory=list)
    configuration: Dict[str, str] = field(default_factory=dict)
    channels: List[str] = field(default_factory=lambda: ["current"])
    photon: bool = False
    serverless: bool = False


@dataclass
class PipelineState:
    pipeline_id: str
    name: str
    state: str
    cluster_id: Optional[str] = None
    clusters: List[Dict[str, Any]] = field(default_factory=list)
    last_update: Optional[datetime] = None


@dataclass
class PipelineUpdate:
    id: str
    pipeline_id: str
    status: str
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    message: Optional[str] = None
    errors: List[str] = field(default_factory=list)


class DLTClient:
    def __init__(self, databricks_client):
        self.client = databricks_client

    async def create_pipeline(
        self,
        name: str,
        target: str,
        sql_streams: Optional[List[str]] = None,
        notebooks: Optional[List[str]] = None,
        configuration: Optional[Dict[str, str]] = None,
        channel: str = "current"
    ) -> Dict[str, Any]:
        pipeline_spec = {
            "name": name,
            "target": target,
            "configuration": configuration or {},
            "channel": channel
        }

        if sql_streams:
            pipeline_spec["flow"] = sql_streams

        if notebooks:
            pipeline_spec["notebooks"] = notebooks

        return await self.client.create_pipeline(pipeline_spec)

    async def get_pipeline(self, pipeline_id: str) -> PipelineState:
        pipeline_data = await self.client.get_pipeline(pipeline_id)

        return PipelineState(
            pipeline_id=pipeline_id,
            name=pipeline_data.get("name", ""),
            state=pipeline_data.get("state", "unknown"),
            cluster_id=pipeline_data.get("cluster_id"),
            clusters=pipeline_data.get("clusters", [])
        )

    async def start_pipeline(self, pipeline_id: str) -> Dict[str, Any]:
        return await self.client.start_pipeline(pipeline_id)

    async def stop_pipeline(self, pipeline_id: str) -> Dict[str, Any]:
        return await self.client.stop_pipeline(pipeline_id)

    async def get_pipeline_updates(self, pipeline_id: str) -> List[PipelineUpdate]:
        updates_data = await self.client.get_pipeline_updates(pipeline_id)

        return [
            PipelineUpdate(
                id=u.get("update_id"),
                pipeline_id=pipeline_id,
                status=u.get("state"),
                message=u.get("message")
            )
            for u in updates_data
        ]

    async def list_pipelines(self) -> List[Dict[str, Any]]:
        return []

    async def delete_pipeline(self, pipeline_id: str) -> Dict[str, Any]:
        return {"success": True, "pipeline_id": pipeline_id}

    async def update_pipeline(
        self,
        pipeline_id: str,
        configuration: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        return {
            "success": True,
            "pipeline_id": pipeline_id,
            "configuration": configuration
        }

    def generate_pipeline_spec(
        self,
        kpi_name: str,
        source_tables: List[str],
        transformations: List[str],
        quality_checks: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        flow = []

        for idx, sql in enumerate(transformations):
            flow.append({
                "id": f"flow_{idx}",
                "name": f"{kpi_name}_transform_{idx}",
                "sql": sql
            })

        if quality_checks:
            for check in quality_checks:
                flow.append({
                    "id": f"quality_{check.get('name', 'check')}",
                    "name": check.get("name"),
                    "expectations": [
                        {
                            "name": check.get("name"),
                            "assertion": check.get("expression")
                        }
                    ]
                })

        return {
            "name": f"dlt_{kpi_name}",
            "target": f"analytics.{kpi_name}_metrics",
            "flow": flow,
            "configuration": {
                "pipelines.enableTrackHistory": "true",
                "pipelines.autoOptimize.enabled": "true"
            }
        }
