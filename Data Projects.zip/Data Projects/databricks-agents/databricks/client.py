from typing import Any, Dict, List, Optional
import os
import logging

logger = logging.getLogger(__name__)


class DatabricksClient:
    def __init__(self, workspace_url: str, token: Optional[str] = None):
        self.workspace_url = workspace_url.rstrip("/")
        self.token = token or os.environ.get("DATABRICKS_TOKEN")
        self._api_version = "2.1"

    def _get_headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }

    def _build_url(self, path: str) -> str:
        return f"{self.workspace_url}/api/{self._api_version}/{path.lstrip('/')}"

    async def get_jobs(self) -> List[Dict[str, Any]]:
        return []

    async def get_job(self, job_id: str) -> Dict[str, Any]:
        return {}

    async def run_job(self, job_id: str, **kwargs) -> Dict[str, Any]:
        return {"run_id": "mock_run_id", "state": "running"}

    async def get_job_runs(self, job_id: str, limit: int = 25) -> List[Dict[str, Any]]:
        return []

    async def get_cluster(self, cluster_id: str) -> Dict[str, Any]:
        return {}

    async def get_clusters(self) -> List[Dict[str, Any]]:
        return []

    async def restart_cluster(self, cluster_id: str) -> Dict[str, Any]:
        return {"cluster_id": cluster_id, "state": "restarted"}

    async def terminate_cluster(self, cluster_id: str) -> Dict[str, Any]:
        return {"cluster_id": cluster_id, "state": "terminated"}

    async def execute_sql(self, warehouse_id: str, statement: str) -> Dict[str, Any]:
        return {"statement_id": "mock_statement_id", "status": "running"}

    async def get_sql_statement_result(self, statement_id: str) -> Dict[str, Any]:
        return {"status": "completed", "data": []}

    async def list_catalogs(self) -> List[Dict[str, Any]]:
        return []

    async def list_schemas(self, catalog: str) -> List[Dict[str, Any]]:
        return []

    async def list_tables(self, catalog: str, schema: str) -> List[Dict[str, Any]]:
        return []

    async def get_table(self, catalog: str, schema: str, table: str) -> Dict[str, Any]:
        return {}

    async def get_lineage(self, catalog: str, schema: str, table: str) -> Dict[str, Any]:
        return {}

    async def create_pipeline(self, pipeline_spec: Dict[str, Any]) -> Dict[str, Any]:
        return {"pipeline_id": "mock_pipeline_id", "state": "created"}

    async def get_pipeline(self, pipeline_id: str) -> Dict[str, Any]:
        return {}

    async def start_pipeline(self, pipeline_id: str) -> Dict[str, Any]:
        return {"pipeline_id": pipeline_id, "state": "starting"}

    async def stop_pipeline(self, pipeline_id: str) -> Dict[str, Any]:
        return {"pipeline_id": pipeline_id, "state": "stopped"}

    async def get_pipeline_updates(self, pipeline_id: str) -> List[Dict[str, Any]]:
        return []

    async def get_system_tables_jobs(self) -> List[Dict[str, Any]]:
        return []

    async def get_system_tables_runs(self, job_id: Optional[str] = None) -> List[Dict[str, Any]]:
        return []
