from typing import Any, Dict, List, Optional
from dataclasses import dataclass


@dataclass
class Column:
    name: str
    type: str
    nullable: bool = True
    comment: Optional[str] = None


@dataclass
class Table:
    catalog: str
    schema: str
    name: str
    table_type: str
    columns: List[Column]
    owner: Optional[str] = None
    comment: Optional[str] = None


@dataclass
class Schema:
    catalog: str
    name: str
    owner: Optional[str] = None
    comment: Optional[str] = None


@dataclass
class Catalog:
    name: str
    owner: Optional[str] = None
    comment: Optional[str] = None


@dataclass
class LineageNode:
    id: str
    name: str
    type: str
    source_type: str


@dataclass
class LineageEdge:
    source: str
    target: str
    edge_type: str


class UnityCatalogClient:
    def __init__(self, databricks_client):
        self.client = databricks_client

    async def list_catalogs(self) -> List[Catalog]:
        catalogs_data = await self.client.list_catalogs()
        return [
            Catalog(
                name=c.get("name"),
                owner=c.get("owner"),
                comment=c.get("comment")
            )
            for c in catalogs_data
        ]

    async def list_schemas(self, catalog: str) -> List[Schema]:
        schemas_data = await self.client.list_schemas(catalog)
        return [
            Schema(
                catalog=catalog,
                name=s.get("name"),
                owner=s.get("owner"),
                comment=s.get("comment")
            )
            for s in schemas_data
        ]

    async def list_tables(self, catalog: str, schema: str) -> List[Table]:
        tables_data = await self.client.list_tables(catalog, schema)
        return [
            Table(
                catalog=catalog,
                schema=schema,
                name=t.get("name"),
                table_type=t.get("table_type", "MANAGED"),
                columns=[]
            )
            for t in tables_data
        ]

    async def get_table(self, catalog: str, schema: str, table: str) -> Optional[Table]:
        table_data = await self.client.get_table(catalog, schema, table)
        if not table_data:
            return None

        columns = [
            Column(
                name=col.get("name"),
                type=col.get("type"),
                nullable=col.get("nullable", True),
                comment=col.get("comment")
            )
            for col in table_data.get("columns", [])
        ]

        return Table(
            catalog=catalog,
            schema=schema,
            name=table,
            table_type=table_data.get("table_type", "MANAGED"),
            columns=columns,
            owner=table_data.get("owner"),
            comment=table_data.get("comment")
        )

    async def get_lineage(self, catalog: str, schema: str, table: str) -> Dict[str, Any]:
        lineage_data = await self.client.get_lineage(catalog, schema, table)

        nodes = [
            LineageNode(
                id=n.get("id"),
                name=n.get("name"),
                type=n.get("type"),
                source_type=n.get("source_type")
            )
            for n in lineage_data.get("nodes", [])
        ]

        edges = [
            LineageEdge(
                source=e.get("source"),
                target=e.get("target"),
                edge_type=e.get("edge_type", "DATA_FLOW")
            )
            for e in lineage_data.get("edges", [])
        ]

        return {
            "nodes": nodes,
            "edges": edges,
            "upstream_count": len([n for n in nodes if n.source_type == "upstream"]),
            "downstream_count": len([n for n in nodes if n.source_type == "downstream"])
        }

    async def search_objects(
        self,
        query: str,
        catalog: Optional[str] = None,
        object_types: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        return []

    async def get_column_lineage(self, catalog: str, schema: str, table: str, column: str) -> Dict[str, Any]:
        return {}

    async def get_permissions(self, catalog: str, schema: str, table: str) -> Dict[str, Any]:
        return {
            "principal": "users",
            "privileges": ["SELECT"]
        }

    async def set_permissions(
        self,
        catalog: str,
        schema: str,
        table: str,
        principal: str,
        privileges: List[str]
    ) -> Dict[str, Any]:
        return {
            "success": True,
            "catalog": catalog,
            "schema": schema,
            "table": table,
            "principal": principal,
            "privileges": privileges
        }

    async def create_table(
        self,
        catalog: str,
        schema: str,
        table: str,
        columns: List[Column],
        table_type: str = "MANAGED",
        comment: Optional[str] = None
    ) -> Dict[str, Any]:
        return {
            "success": True,
            "catalog": catalog,
            "schema": schema,
            "table": table,
            "table_type": table_type
        }

    async def update_table_comment(
        self,
        catalog: str,
        schema: str,
        table: str,
        comment: str
    ) -> Dict[str, Any]:
        return {
            "success": True,
            "catalog": catalog,
            "schema": schema,
            "table": table,
            "comment": comment
        }
