from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class Task:
    task_key: str
    notebook_task: Optional[Dict[str, Any]] = None
    spark_jar_task: Optional[Dict[str, Any]] = None
    spark_python_task: Optional[Dict[str, Any]] = None
    sql_task: Optional[Dict[str, Any]] = None
    depends_on: List[str] = field(default_factory=list)
    timeout_seconds: Optional[int] = None
    max_retries: Optional[int] = None


@dataclass
class Job:
    job_id: str
    name: str
    schedule: Optional[Dict[str, Any]] = None
    tasks: List[Task] = field(default_factory=list)
    timeout_seconds: Optional[int] = None
    max_concurrent_runs: int = 1
    git_source: Optional[Dict[str, Any]] = None


@dataclass
class JobRun:
    run_id: str
    job_id: str
    number_in_job: int
    state: str
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    tasks: List[Dict[str, Any]] = field(default_factory=list)


class WorkflowsClient:
    def __init__(self, databricks_client):
        self.client = databricks_client

    async def create_job(
        self,
        name: str,
        tasks: List[Task],
        schedule: Optional[Dict[str, Any]] = None,
        timeout_seconds: Optional[int] = None
    ) -> Dict[str, Any]:
        job_spec = {
            "name": name,
            "max_concurrent_runs": 1,
            "tasks": [
                {
                    "task_key": task.task_key,
                    "depends_on": [{"task_key": dep} for dep in task.depends_on]
                }
                for task in tasks
            ]
        }

        for task in tasks:
            if task.notebook_task:
                pass
            elif task.spark_jar_task:
                pass
            elif task.spark_python_task:
                pass
            elif task.sql_task:
                pass

        if schedule:
            job_spec["schedule"] = schedule

        if timeout_seconds:
            job_spec["timeout_seconds"] = timeout_seconds

        return {"job_id": "mock_job_id", "name": name}

    async def get_job(self, job_id: str) -> Job:
        job_data = await self.client.get_job(job_id)

        return Job(
            job_id=job_id,
            name=job_data.get("name", ""),
            schedule=job_data.get("schedule"),
            timeout_seconds=job_data.get("timeout_seconds")
        )

    async def run_job(
        self,
        job_id: str,
        notebook_params: Optional[Dict[str, str]] = None,
        jar_params: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        return await self.client.run_job(
            job_id,
            notebook_params=notebook_params,
            jar_params=jar_params
        )

    async def get_run(self, run_id: str) -> JobRun:
        return JobRun(
            run_id=run_id,
            job_id="mock_job_id",
            number_in_job=1,
            state="running"
        )

    async def cancel_run(self, run_id: str) -> Dict[str, Any]:
        return {"run_id": run_id, "cancelled": True}

    async def delete_job(self, job_id: str) -> Dict[str, Any]:
        return {"job_id": job_id, "deleted": True}

    async def update_job(
        self,
        job_id: str,
        name: Optional[str] = None,
        schedule: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        return {"job_id": job_id, "updated": True}

    async def list_jobs(self) -> List[Dict[str, Any]]:
        return await self.client.get_jobs()

    async def list_runs(
        self,
        job_id: str,
        limit: int = 25,
        active_only: bool = False
    ) -> List[JobRun]:
        runs_data = await self.client.get_job_runs(job_id, limit)

        return [
            JobRun(
                run_id=r.get("run_id"),
                job_id=job_id,
                number_in_job=r.get("number_in_job"),
                state=r.get("state", {}).get("life_cycle_state", "unknown")
            )
            for r in runs_data
        ]

    def create_notebook_task(
        self,
        notebook_path: str,
        base_parameters: Optional[Dict[str, str]] = None
    ) -> Task:
        return Task(
            task_key=notebook_path.split("/")[-1].replace(".py", "").replace(".dbc", ""),
            notebook_task={
                "notebook_path": notebook_path,
                "base_parameters": base_parameters or {}
            }
        )

    def create_sql_task(
        self,
        warehouse_id: str,
        sql_query: str,
        alert: Optional[Dict[str, Any]] = None
    ) -> Task:
        task = Task(
            task_key=f"sql_task_{hash(sql_query) % 10000}",
            sql_task={
                "warehouse_id": warehouse_id,
                "query": sql_query
            }
        )

        if alert:
            task.sql_task["alert"] = alert

        return task

    def create_python_task(
        self,
        python_file: str,
        parameters: Optional[List[str]] = None
    ) -> Task:
        return Task(
            task_key=python_file.split("/")[-1].replace(".py", ""),
            spark_python_task={
                "python_file": python_file,
                "parameters": parameters or []
            }
        )
