from typing import Any, Dict, List, Optional
from datetime import datetime
import json


class AgentMemory:
    def __init__(self, vector_store=None):
        self._memory = []
        self._context = {}
        self._vector_store = vector_store

    def add_interaction(
        self,
        user_query: str,
        agent_response: str,
        agent_type: str,
        context: Optional[Dict[str, Any]] = None
    ):
        entry = {
            "id": len(self._memory) + 1,
            "timestamp": datetime.utcnow().isoformat(),
            "user_query": user_query,
            "agent_response": agent_response,
            "agent_type": agent_type,
            "context": context or {},
            "successful": True
        }
        self._memory.append(entry)

    def get_recent(self, count: int = 10) -> List[Dict[str, Any]]:
        return self._memory[-count:]

    def search(self, query: str) -> List[Dict[str, Any]]:
        query_lower = query.lower()
        results = []
        for entry in self._memory:
            if query_lower in entry.get("user_query", "").lower():
                results.append(entry)
            elif query_lower in entry.get("agent_response", "").lower():
                results.append(entry)
        return results[-10:]

    def get_context(self) -> Dict[str, Any]:
        return self._context.copy()

    def set_context(self, key: str, value: Any):
        self._context[key] = value

    def clear_context(self):
        self._context = {}


class KPIRegistry:
    def __init__(self):
        self._kpis = {}

    def register_kpi(
        self,
        name: str,
        formula: str,
        description: str,
        owner: str,
        tags: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        kpi_id = f"kpi_{name}_{datetime.utcnow().timestamp()}"
        kpi = {
            "id": kpi_id,
            "name": name,
            "formula": formula,
            "description": description,
            "owner": owner,
            "tags": tags or [],
            "status": "active",
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat()
        }
        self._kpis[kpi_id] = kpi
        return kpi

    def get_kpi(self, kpi_id: str) -> Optional[Dict[str, Any]]:
        return self._kpis.get(kpi_id)

    def list_kpis(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        kpis = list(self._kpis.values())
        if status:
            kpis = [k for k in kpis if k.get("status") == status]
        return kpis

    def update_kpi(self, kpi_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if kpi_id in self._kpis:
            self._kpis[kpi_id].update(updates)
            self._kpis[kpi_id]["updated_at"] = datetime.utcnow().isoformat()
            return self._kpis[kpi_id]
        return None


class IncidentHistory:
    def __init__(self):
        self._incidents = {}

    def create_incident(
        self,
        incident_type: str,
        severity: str,
        description: str,
        source: str
    ) -> Dict[str, Any]:
        incident_id = f"inc_{datetime.utcnow().timestamp()}"
        incident = {
            "id": incident_id,
            "type": incident_type,
            "severity": severity,
            "description": description,
            "source": source,
            "status": "open",
            "created_at": datetime.utcnow().isoformat(),
            "resolved_at": None,
            "root_cause": None,
            "remediation": None,
            "affected_tables": [],
            "affected_dashboards": []
        }
        self._incidents[incident_id] = incident
        return incident

    def get_incident(self, incident_id: str) -> Optional[Dict[str, Any]]:
        return self._incidents.get(incident_id)

    def list_incidents(
        self,
        status: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        incidents = list(self._incidents.values())
        if status:
            incidents = [i for i in incidents if i.get("status") == status]
        if severity:
            incidents = [i for i in incidents if i.get("severity") == severity]
        return sorted(incidents, key=lambda x: x["created_at"], reverse=True)[:limit]

    def resolve_incident(
        self,
        incident_id: str,
        root_cause: str,
        remediation: str
    ) -> Optional[Dict[str, Any]]:
        if incident_id in self._incidents:
            self._incidents[incident_id]["status"] = "resolved"
            self._incidents[incident_id]["resolved_at"] = datetime.utcnow().isoformat()
            self._incidents[incident_id]["root_cause"] = root_cause
            self._incidents[incident_id]["remediation"] = remediation
            return self._incidents[incident_id]
        return None


class SemanticModel:
    def __init__(self):
        self._entities = {}
        self._relationships = []

    def add_entity(
        self,
        name: str,
        entity_type: str,
        attributes: Dict[str, Any]
    ) -> Dict[str, Any]:
        entity_id = f"entity_{name}_{datetime.utcnow().timestamp()}"
        entity = {
            "id": entity_id,
            "name": name,
            "type": entity_type,
            "attributes": attributes,
            "created_at": datetime.utcnow().isoformat()
        }
        self._entities[entity_id] = entity
        return entity

    def add_relationship(
        self,
        from_entity: str,
        to_entity: str,
        relationship_type: str,
        properties: Optional[Dict[str, Any]] = None
    ):
        self._relationships.append({
            "from": from_entity,
            "to": to_entity,
            "type": relationship_type,
            "properties": properties or {},
            "created_at": datetime.utcnow().isoformat()
        })

    def get_entity(self, entity_id: str) -> Optional[Dict[str, Any]]:
        return self._entities.get(entity_id)

    def find_related_entities(self, entity_id: str) -> List[Dict[str, Any]]:
        related = []
        for rel in self._relationships:
            if rel["from"] == entity_id:
                related.append({"entity": rel["to"], "relationship": rel["type"]})
            elif rel["to"] == entity_id:
                related.append({"entity": rel["from"], "relationship": rel["type"]})
        return related

    def get_entity_graph(self) -> Dict[str, Any]:
        return {
            "entities": list(self._entities.values()),
            "relationships": self._relationships
        }
