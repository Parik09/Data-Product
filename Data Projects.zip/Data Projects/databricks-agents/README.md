# Databricks AI Agents Platform

Autonomous Data Engineering & Support AI Platform using Databricks Lakehouse + Mosaic AI Agents.

## Overview

This platform provides AI agents for:
- **Support Engineer Agent**: Pipeline failure detection, root cause analysis, impact analysis, automated remediation
- **Data Engineer Agent**: Convert KPI definitions into production-grade data pipelines
- **Planner Agent**: Break requests into tasks and assign agents
- **Reviewer Agent**: Validate SQL, governance, PII exposure
- **Data Quality Agent**: Monitor data quality metrics
- **Cost Optimization Agent**: Analyze and optimize costs

## Architecture

```
User Request
     │
     ▼
AI Agent Gateway
     │
Planner Agent
     │
 ┌───┼───────────────┐
 ▼   ▼               ▼
DE  Support      Reviewer
Agent Agent       Agent
     │
     ▼
DLT + Workflows
     │
Delta Tables
     │
BI / Applications
```

## Installation

```bash
pip install -r requirements.txt
```

## Configuration

Copy `config/config.yaml.example` to `config/config.yaml` and configure:

- Databricks workspace URL
- Unity Catalog settings
- Agent behavior parameters
- Notification settings

## Usage

### Initialize the Platform

```python
from databricks_agents import AgentPlatform

platform = AgentPlatform(config_path="config/config.yaml")
platform.initialize()
```

### Support Engineer Workflow

```python
from databricks_agents.support import SupportEngineerAgent

support_agent = SupportEngineerAgent(config)
incident = support_agent.detect_failures()
if incident:
    root_cause = support_agent.analyze_root_cause(incident)
    impact = support_agent.analyze_downstream_impact(incident)
    remediation = support_agent.execute_remediation(incident)
```

### Data Engineer Workflow

```python
from databricks_agents.engineer import DataEngineerAgent

de_agent = DataEngineerAgent(config)
kpi_definition = "Customer retention = users active in last 30 days."
pipeline = de_agent.generate_pipeline(kpi_definition)
de_agent.deploy_pipeline(pipeline)
```

### Full Orchestration

```python
from databricks_agents.orchestration import AgentOrchestrator

orchestrator = AgentOrchestrator(config)
result = orchestrator.process_request("Create pipeline for customer retention KPI")
```

## Development

### Run Tests

```bash
pytest tests/
```

### Code Quality

```bash
ruff check .
ruff format .
```

## Project Structure

```
databricks_agents/
├── agents/
│   ├── __init__.py
│   ├── base.py
│   ├── support_engineer.py
│   ├── data_engineer.py
│   ├── planner.py
│   ├── reviewer.py
│   ├── data_quality.py
│   └── cost_optimization.py
├── orchestration/
│   ├── __init__.py
│   ├── gateway.py
│   └── task_queue.py
├── databricks/
│   ├── __init__.py
│   ├── client.py
│   ├── unity_catalog.py
│   ├── dlt.py
│   └── workflows.py
├── config/
│   └── config.yaml
├── storage/
│   └── memory.py
├── utils/
│   ├── __init__.py
│   ├── logging.py
│   └── validators.py
├── main.py
└── requirements.txt
```

## License

Proprietary - Internal Use Only
