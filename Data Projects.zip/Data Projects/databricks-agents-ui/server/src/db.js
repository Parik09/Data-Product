import fs from "fs";
import path from "path";
import sqlite3 from "sqlite3";
import { v4 as uuidv4 } from "uuid";

sqlite3.verbose();

const dbPath = path.resolve(process.cwd(), "server", "data", "platform.db");

if (!fs.existsSync(path.dirname(dbPath))) {
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
}

export const db = new sqlite3.Database(dbPath);

async function ensureOperationalSeedData() {
  const runCount = await get("SELECT COUNT(*) as cnt FROM pipeline_runs");
  if ((runCount?.cnt || 0) === 0) {
    const allPipelines = await all("SELECT id, status, quality_score FROM pipelines ORDER BY created_at ASC");
    const errorStages = ["extract", "transform", "load"];
    for (let index = 0; index < allPipelines.length; index += 1) {
      const p = allPipelines[index];
      for (let runIndex = 0; runIndex < 4; runIndex += 1) {
        const runStatus =
          p.status === "failed" && runIndex === 3
            ? "failed"
            : p.status === "running" && runIndex === 3
              ? "running"
              : runIndex === 1 && index % 8 === 0
                ? "failed"
                : "healthy";

        const duration = 180 + ((index + runIndex) % 7) * 35;
        const rows = 9000 + (index % 9) * 750 + runIndex * 400;
        const finishedAt = new Date(Date.now() - (index * 4 + runIndex) * 3600 * 1000).toISOString();
        const startedAt = new Date(new Date(finishedAt).getTime() - duration * 1000).toISOString();
        const errorStage = runStatus === "failed" ? errorStages[(index + runIndex) % errorStages.length] : null;
        const errorMessage = runStatus === "failed" ? `Pipeline stage ${errorStage} encountered a deterministic mock failure` : null;

        await run(
          `INSERT INTO pipeline_runs (id,pipeline_id,trigger_source,status,started_at,finished_at,duration_sec,rows_processed,error_stage,error_message,cost_usd,dq_score)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
          [
            uuidv4(),
            p.id,
            runIndex % 2 === 0 ? "scheduler" : "manual",
            runStatus,
            startedAt,
            runStatus === "running" ? new Date().toISOString() : finishedAt,
            duration,
            rows,
            errorStage,
            errorMessage,
            Number((0.9 + duration / 180 + rows / 15000).toFixed(2)),
            runStatus === "failed" ? Number((p.quality_score - 25).toFixed(1)) : p.quality_score,
          ]
        );
      }
    }
  }
}

export function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function onRun(err) {
      if (err) return reject(err);
      resolve({ lastID: this.lastID, changes: this.changes });
    });
  });
}

export function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) return reject(err);
      resolve(row);
    });
  });
}

export function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}

export async function initDb() {
  await run(`
    CREATE TABLE IF NOT EXISTS kpis (
      id TEXT PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,
      definition TEXT NOT NULL,
      target_value REAL,
      owner TEXT,
      status TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS pipelines (
      id TEXT PRIMARY KEY,
      kpi_id TEXT,
      name TEXT NOT NULL,
      status TEXT NOT NULL,
      sql_text TEXT,
      schedule_cron TEXT,
      environment TEXT NOT NULL,
      quality_score REAL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS incidents (
      id TEXT PRIMARY KEY,
      pipeline_id TEXT,
      severity TEXT NOT NULL,
      category TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT NOT NULL,
      root_cause TEXT,
      impact_json TEXT,
      remediation_json TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS agent_runs (
      id TEXT PRIMARY KEY,
      run_type TEXT NOT NULL,
      trigger_payload TEXT,
      status TEXT NOT NULL,
      started_at TEXT NOT NULL,
      finished_at TEXT
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS agent_tasks (
      id TEXT PRIMARY KEY,
      run_id TEXT NOT NULL,
      agent_name TEXT NOT NULL,
      task_name TEXT NOT NULL,
      status TEXT NOT NULL,
      result_json TEXT,
      started_at TEXT NOT NULL,
      finished_at TEXT
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS lineage_edges (
      id TEXT PRIMARY KEY,
      source_asset TEXT NOT NULL,
      target_asset TEXT NOT NULL,
      edge_type TEXT NOT NULL,
      created_at TEXT NOT NULL
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS quality_checks (
      id TEXT PRIMARY KEY,
      pipeline_id TEXT NOT NULL,
      check_name TEXT NOT NULL,
      status TEXT NOT NULL,
      details TEXT,
      checked_at TEXT NOT NULL
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS cost_metrics (
      id TEXT PRIMARY KEY,
      pipeline_id TEXT,
      metric_name TEXT NOT NULL,
      metric_value REAL NOT NULL,
      measured_at TEXT NOT NULL
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS pipeline_runs (
      id TEXT PRIMARY KEY,
      pipeline_id TEXT NOT NULL,
      trigger_source TEXT NOT NULL,
      status TEXT NOT NULL,
      started_at TEXT NOT NULL,
      finished_at TEXT NOT NULL,
      duration_sec REAL NOT NULL,
      rows_processed INTEGER NOT NULL,
      error_stage TEXT,
      error_message TEXT,
      cost_usd REAL NOT NULL,
      dq_score REAL
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      actor TEXT NOT NULL,
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT,
      details TEXT,
      created_at TEXT NOT NULL
    )
  `);
}

export async function seedDbIfEmpty() {
  const kpiCount = await get("SELECT COUNT(*) as cnt FROM kpis");
  if (kpiCount?.cnt > 0) {
    await ensureOperationalSeedData();
    return;
  }

  const now = new Date().toISOString();
  const starterKpis = [
    ["customer_retention", "users active in last 30 days / total users", 80, "business_analytics"],
    ["daily_active_users", "count distinct active users per day", 50000, "product"],
    ["revenue_per_user", "total revenue / active users", 150, "finance"],
  ];

  for (const [name, definition, target, owner] of starterKpis) {
    await run(
      `INSERT INTO kpis (id,name,definition,target_value,owner,status,created_at,updated_at)
       VALUES (?,?,?,?,?,?,?,?)`,
      [uuidv4(), name, definition, target, owner, "active", now, now]
    );
  }

  const kpis = await all("SELECT id, name FROM kpis");
  for (let i = 0; i < 120; i += 1) {
    const kpi = kpis[i % kpis.length];
    await run(
      `INSERT INTO pipelines (id,kpi_id,name,status,sql_text,schedule_cron,environment,quality_score,created_at,updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?)`,
      [
        uuidv4(),
        kpi.id,
        `pipe_${kpi.name}_${i + 1}`,
        i % 9 === 0 ? "failed" : i % 5 === 0 ? "running" : "healthy",
        "SELECT * FROM source_table",
        "0 */6 * * *",
        i % 3 === 0 ? "prod" : i % 2 === 0 ? "qa" : "dev",
        85 + (i % 15),
        now,
        now,
      ]
    );
  }

  await ensureOperationalSeedData();

  const pipelines = await all("SELECT id, name, status FROM pipelines ORDER BY created_at ASC LIMIT 36");
  for (let idx = 0; idx < pipelines.length; idx += 1) {
    const p = pipelines[idx];
    if (p.status === "failed" || idx % 5 === 0) {
      const severity = p.status === "failed" ? (idx % 2 === 0 ? "critical" : "high") : "medium";
      const category = idx % 3 === 0 ? "job_failure" : idx % 3 === 1 ? "sla_breach" : "freshness_violation";
      await run(
        `INSERT INTO incidents (id,pipeline_id,severity,category,message,status,created_at,updated_at)
         VALUES (?,?,?,?,?,?,?,?)`,
        [
          uuidv4(),
          p.id,
          severity,
          category,
          `Incident on ${p.name}: ${category.replace("_", " ")}`,
          idx % 4 === 0 ? "investigating" : "open",
          now,
          now,
        ]
      );
    }
  }

  const lineageAssets = [
    ["raw.customers", "staging.customers_clean"],
    ["raw.orders", "staging.orders_clean"],
    ["staging.customers_clean", "analytics.customer_kpis"],
    ["staging.orders_clean", "analytics.revenue_kpis"],
    ["analytics.customer_kpis", "bi.dashboard_customer"],
    ["analytics.revenue_kpis", "bi.dashboard_revenue"],
  ];

  for (const [src, trg] of lineageAssets) {
    await run(
      `INSERT INTO lineage_edges (id,source_asset,target_asset,edge_type,created_at)
       VALUES (?,?,?,?,?)`,
      [uuidv4(), src, trg, "DATA_FLOW", now]
    );
  }
}

export async function logAudit(actor, action, entityType, entityId = null, details = {}) {
  await run(
    `INSERT INTO audit_logs (id,actor,action,entity_type,entity_id,details,created_at)
     VALUES (?,?,?,?,?,?,?)`,
    [uuidv4(), actor, action, entityType, entityId, JSON.stringify(details), new Date().toISOString()]
  );
}
