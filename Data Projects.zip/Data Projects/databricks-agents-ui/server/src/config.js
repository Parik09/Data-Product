import fs from "fs";
import path from "path";
import YAML from "yaml";

const configPath = path.resolve(
  process.cwd(),
  "..",
  "databricks-agents",
  "config",
  "config.yaml"
);

export function loadPlatformConfig() {
  try {
    const content = fs.readFileSync(configPath, "utf8");
    return YAML.parse(content);
  } catch {
    return {
      agents: {
        support_engineer: { enabled: true, auto_remediation: { allowed_actions: ["job_rerun", "cluster_restart", "sql_patch"] } },
        data_engineer: { enabled: true, default_pipeline_language: "dlt" },
        planner: { enabled: true },
        reviewer: { enabled: true },
        data_quality: { enabled: true },
        cost_optimization: { enabled: true },
      },
      performance: {
        agent_response_timeout_seconds: 10,
        pipeline_generation_timeout_seconds: 120,
        incident_detection_latency_seconds: 300,
      },
      scalability: { max_pipelines: 10000, max_concurrent_jobs: 500 },
      security: { enable_rbac: true, enable_column_masking: true, enable_audit_logging: true },
      compliance: { enable_action_traceability: true, enable_immutable_logs: true, enable_approval_workflow: true },
    };
  }
}

export const PLATFORM_CONFIG = loadPlatformConfig();
