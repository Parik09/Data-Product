import express from "express";
import { v4 as uuidv4 } from "uuid";
import {
  analyzeImpact,
  analyzeRootCause,
  detectIncidents,
  remediateIncident,
  runCostAnalysis,
  runDataQuality,
  runKpiToPipelineFlow,
  runSqlValidation,
} from "./agents.js";
import { PLATFORM_CONFIG } from "./config.js";
import { all, get, logAudit, run } from "./db.js";

export function createApiRouter() {
  const router = express.Router();

  router.get("/health", async (_, res) => {
    res.json({ status: "ok", ts: new Date().toISOString() });
  });

  router.get("/config", async (_, res) => {
    res.json({
      databricks: PLATFORM_CONFIG.databricks,
      agents: PLATFORM_CONFIG.agents,
      performance: PLATFORM_CONFIG.performance,
      security: PLATFORM_CONFIG.security,
      compliance: PLATFORM_CONFIG.compliance,
      scalability: PLATFORM_CONFIG.scalability,
    });
  });

  router.get("/dashboard", async (_, res) => {
    const pipelineCount = await get(`SELECT COUNT(*) as cnt FROM pipelines`);
    const openIncidents = await get(`SELECT COUNT(*) as cnt FROM incidents WHERE status IN ('open','investigating')`);
    const avgQuality = await get(`SELECT COALESCE(AVG(quality_score),0) as avg_quality FROM pipelines`);
    const runs = await get(`SELECT COUNT(*) as cnt FROM agent_runs WHERE status='running'`);

    const byStatus = await all(`SELECT status, COUNT(*) as count FROM pipelines GROUP BY status`);
    const incidentsBySeverity = await all(`SELECT severity, COUNT(*) as count FROM incidents GROUP BY severity`);

    res.json({
      totals: {
        pipelines: pipelineCount.cnt,
        incidents: openIncidents.cnt,
        quality: Number(avgQuality.avg_quality || 0).toFixed(1),
        activeAgentRuns: runs.cnt,
      },
      byStatus,
      incidentsBySeverity,
    });
  });

  router.get("/kpis", async (_, res) => {
    const rows = await all(`SELECT * FROM kpis ORDER BY updated_at DESC`);
    res.json(rows);
  });

  router.post("/kpis", async (req, res) => {
    const { name, definition, targetValue, owner } = req.body;
    if (!name || !definition) {
      return res.status(400).json({ error: "name and definition are required" });
    }
    const id = uuidv4();
    await run(
      `INSERT INTO kpis (id,name,definition,target_value,owner,status,created_at,updated_at)
       VALUES (?,?,?,?,?,?,?,?)`,
      [id, name, definition, targetValue ?? null, owner ?? "business_analyst", "active", new Date().toISOString(), new Date().toISOString()]
    );
    await logAudit("business_analyst", "CREATE_KPI", "kpi", id, req.body);
    const created = await get(`SELECT * FROM kpis WHERE id=?`, [id]);
    res.status(201).json(created);
  });

  router.post("/kpis/:id/generate-pipeline", async (req, res) => {
    try {
      const payload = await runKpiToPipelineFlow(req.params.id, req.body.environment || "dev");
      res.status(202).json(payload);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

  router.get("/pipelines", async (req, res) => {
    const where = req.query.status ? `WHERE p.status = ?` : "";
    const rows = await all(
      `SELECT p.*, k.name as kpi_name
       FROM pipelines p
       LEFT JOIN kpis k ON p.kpi_id = k.id
       ${where}
       ORDER BY p.updated_at DESC`,
      req.query.status ? [req.query.status] : []
    );
    res.json(rows);
  });

  router.post("/pipelines/:id/run", async (req, res) => {
    const id = req.params.id;
    await run(`UPDATE pipelines SET status='running', updated_at=? WHERE id=?`, [new Date().toISOString(), id]);
    setTimeout(async () => {
      await run(`UPDATE pipelines SET status='healthy', quality_score=?, updated_at=? WHERE id=?`, [90 + Math.floor(Math.random() * 10), new Date().toISOString(), id]);
    }, 1400);
    await logAudit("data_engineer_agent", "RUN_PIPELINE", "pipeline", id, {});
    res.json({ accepted: true });
  });

  router.post("/pipelines/:id/validate", async (req, res) => {
    const pipeline = await get(`SELECT * FROM pipelines WHERE id=?`, [req.params.id]);
    if (!pipeline) return res.status(404).json({ error: "pipeline not found" });
    const result = await runSqlValidation(pipeline.sql_text || "");
    await logAudit("reviewer_agent", "VALIDATE_SQL", "pipeline", req.params.id, result);
    res.json(result);
  });

  router.post("/pipelines/:id/quality", async (req, res) => {
    try {
      const result = await runDataQuality(req.params.id);
      res.json(result);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

  router.get("/incidents", async (_, res) => {
    const rows = await all(
      `SELECT i.*, p.name as pipeline_name
       FROM incidents i
       LEFT JOIN pipelines p ON p.id = i.pipeline_id
       ORDER BY i.updated_at DESC`
    );
    res.json(rows);
  });

  router.post("/incidents/detect", async (_, res) => {
    const ids = await detectIncidents();
    res.json({ created: ids.length, ids });
  });

  router.post("/incidents/:id/root-cause", async (req, res) => {
    try {
      const out = await analyzeRootCause(req.params.id);
      res.json(out);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

  router.post("/incidents/:id/impact", async (req, res) => {
    try {
      const out = await analyzeImpact(req.params.id);
      res.json(out);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

  router.post("/incidents/:id/remediate", async (req, res) => {
    try {
      const out = await remediateIncident(req.params.id, req.body.actionType || "job_rerun");
      res.json(out);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

  router.get("/agent-runs", async (_, res) => {
    const rows = await all(`SELECT * FROM agent_runs ORDER BY started_at DESC LIMIT 50`);
    res.json(rows);
  });

  router.get("/agent-runs/:id", async (req, res) => {
    const runRow = await get(`SELECT * FROM agent_runs WHERE id=?`, [req.params.id]);
    const tasks = await all(`SELECT * FROM agent_tasks WHERE run_id=? ORDER BY started_at ASC`, [req.params.id]);
    if (!runRow) return res.status(404).json({ error: "run not found" });
    res.json({ run: runRow, tasks });
  });

  router.get("/lineage", async (_, res) => {
    const edges = await all(`SELECT * FROM lineage_edges ORDER BY created_at ASC`);
    const nodes = [...new Set(edges.flatMap((e) => [e.source_asset, e.target_asset]))].map((id) => ({ id }));
    res.json({ nodes, edges });
  });

  router.post("/cost/analyze", async (_, res) => {
    await runCostAnalysis();
    const costs = await all(
      `SELECT metric_name, ROUND(AVG(metric_value),2) as avg_value
       FROM cost_metrics
       WHERE measured_at >= datetime('now', '-1 day')
       GROUP BY metric_name`
    );
    res.json({ costs });
  });

  router.get("/audit", async (_, res) => {
    const rows = await all(`SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 200`);
    res.json(rows);
  });

  router.post("/ai/summarize", async (req, res) => {
    const prompt = String(req.body.prompt || "");
    const summary = prompt
      ? `AI Summary: ${prompt.slice(0, 140)}${prompt.length > 140 ? "..." : ""}`
      : "AI Summary: No context provided.";
    res.json({ summary, provider: "mock_or_local" });
  });

  return router;
}
