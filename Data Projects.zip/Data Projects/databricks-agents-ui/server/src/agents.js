import { v4 as uuidv4 } from "uuid";
import { PLATFORM_CONFIG } from "./config.js";
import { all, get, run, logAudit } from "./db.js";

const activeTimers = new Map();

function nowIso() {
  return new Date().toISOString();
}

function extractSqlFromKpi(definition, pipelineName) {
  const def = definition.toLowerCase();
  if (def.includes("retention")) {
    return `
WITH users_30d AS (
  SELECT DISTINCT user_id
  FROM raw.events
  WHERE event_date >= DATE('now', '-30 day')
), total_users AS (
  SELECT COUNT(DISTINCT user_id) AS total_cnt
  FROM raw.users
)
SELECT
  '${pipelineName}' AS metric_name,
  (SELECT COUNT(*) FROM users_30d) * 100.0 / (SELECT total_cnt FROM total_users) AS metric_value,
  CURRENT_TIMESTAMP AS computed_at;
`.trim();
  }
  return `SELECT '${pipelineName}' AS metric_name, COUNT(*) AS metric_value, CURRENT_TIMESTAMP AS computed_at FROM raw.events;`;
}

async function createTask(runId, agentName, taskName) {
  const id = uuidv4();
  await run(
    `INSERT INTO agent_tasks (id,run_id,agent_name,task_name,status,started_at)
     VALUES (?,?,?,?,?,?)`,
    [id, runId, agentName, taskName, "running", nowIso()]
  );
  return id;
}

async function completeTask(taskId, result = {}) {
  await run(
    `UPDATE agent_tasks SET status=?, result_json=?, finished_at=? WHERE id=?`,
    ["completed", JSON.stringify(result), nowIso(), taskId]
  );
}

async function failTask(taskId, error) {
  await run(
    `UPDATE agent_tasks SET status=?, result_json=?, finished_at=? WHERE id=?`,
    ["failed", JSON.stringify({ error }), nowIso(), taskId]
  );
}

export async function runKpiToPipelineFlow(kpiId, environment = "dev") {
  const kpi = await get(`SELECT * FROM kpis WHERE id=?`, [kpiId]);
  if (!kpi) throw new Error("KPI not found");

  const runId = uuidv4();
  await run(
    `INSERT INTO agent_runs (id,run_type,trigger_payload,status,started_at)
     VALUES (?,?,?,?,?)`,
    [runId, "kpi_to_pipeline", JSON.stringify({ kpiId, environment }), "running", nowIso()]
  );

  const planTask = await createTask(runId, "planner", "Break request into tasks");
  const deDiscoverTask = await createTask(runId, "data_engineer", "Metadata discovery");
  const deBuildTask = await createTask(runId, "data_engineer", "Generate SQL + DLT pipeline");
  const reviewerTask = await createTask(runId, "reviewer", "Governance + SQL validation");
  const deployTask = await createTask(runId, "data_engineer", "Deployment automation");
  const qualityTask = await createTask(runId, "data_quality", "Setup DQ checks");

  const pipelineName = `pipe_${kpi.name}_${Date.now()}`;
  const sqlText = extractSqlFromKpi(kpi.definition, pipelineName);

  const timer = setTimeout(async () => {
    try {
      await completeTask(planTask, { tasks: 6, assigned: true });
      await completeTask(deDiscoverTask, { discovered_datasets: ["raw.events", "raw.users"] });

      await completeTask(deBuildTask, {
        generated_sql: sqlText,
        dlt_pipeline_name: pipelineName,
        schedule_cron: "0 */6 * * *",
      });

      const violation = /drop\s+table|delete\s+from/i.test(sqlText);
      if (violation) {
        await failTask(reviewerTask, "Unsafe SQL detected by reviewer");
        await run(`UPDATE agent_runs SET status=?, finished_at=? WHERE id=?`, ["failed", nowIso(), runId]);
        await logAudit("reviewer_agent", "BLOCK_PIPELINE", "agent_run", runId, { reason: "unsafe_sql" });
        return;
      }

      await completeTask(reviewerTask, {
        sql_efficiency: "pass",
        governance: "pass",
        pii_exposure: "none",
        schema_compatibility: "pass",
      });

      const pipelineId = uuidv4();
      await run(
        `INSERT INTO pipelines (id,kpi_id,name,status,sql_text,schedule_cron,environment,quality_score,created_at,updated_at)
         VALUES (?,?,?,?,?,?,?,?,?,?)`,
        [pipelineId, kpi.id, pipelineName, "healthy", sqlText, "0 */6 * * *", environment, 95, nowIso(), nowIso()]
      );

      await completeTask(deployTask, { pipeline_id: pipelineId, environment, deployed: true });

      const checks = [
        ["row_count_anomalies", "pass"],
        ["null_spikes", "pass"],
        ["schema_drift", "pass"],
        ["freshness_sla", "pass"],
      ];
      for (const [checkName, status] of checks) {
        await run(
          `INSERT INTO quality_checks (id,pipeline_id,check_name,status,details,checked_at)
           VALUES (?,?,?,?,?,?)`,
          [uuidv4(), pipelineId, checkName, status, JSON.stringify({ source: "data_quality_agent" }), nowIso()]
        );
      }

      await completeTask(qualityTask, { checks_configured: 4 });

      await run(`UPDATE agent_runs SET status=?, finished_at=? WHERE id=?`, ["completed", nowIso(), runId]);
      await logAudit("planner_agent", "RUN_COMPLETED", "agent_run", runId, { kpiId, pipelineName });
    } catch (error) {
      await failTask(deployTask, error.message);
      await run(`UPDATE agent_runs SET status=?, finished_at=? WHERE id=?`, ["failed", nowIso(), runId]);
      await logAudit("system", "RUN_FAILED", "agent_run", runId, { error: error.message });
    }
  }, 1200);

  activeTimers.set(runId, timer);
  return { runId };
}

export async function detectIncidents() {
  const failedPipelines = await all(`SELECT id, name FROM pipelines WHERE status='failed' LIMIT 10`);
  const newItems = [];
  for (const p of failedPipelines) {
    const exists = await get(
      `SELECT id FROM incidents WHERE pipeline_id=? AND status IN ('open','investigating') ORDER BY created_at DESC LIMIT 1`,
      [p.id]
    );
    if (!exists) {
      const id = uuidv4();
      await run(
        `INSERT INTO incidents (id,pipeline_id,severity,category,message,status,created_at,updated_at)
         VALUES (?,?,?,?,?,?,?,?)`,
        [id, p.id, "high", "job_failure", `Pipeline ${p.name} failed`, "open", nowIso(), nowIso()]
      );
      newItems.push(id);
    }
  }
  await logAudit("support_engineer_agent", "DETECT_INCIDENTS", "incident", null, { created: newItems.length });
  return newItems;
}

export async function analyzeRootCause(incidentId) {
  const incident = await get(`SELECT * FROM incidents WHERE id=?`, [incidentId]);
  if (!incident) throw new Error("Incident not found");

  const category = incident.category;
  let rootCause = "Unknown root cause";
  const actions = [];

  if (category === "job_failure") {
    rootCause = "Cluster memory pressure during transformation";
    actions.push("job_rerun", "cluster_restart", "sql_patch");
  } else if (category === "sla_breach") {
    rootCause = "Upstream delay causing freshness breach";
    actions.push("job_rerun", "sql_patch");
  }

  await run(`UPDATE incidents SET root_cause=?, status=?, updated_at=? WHERE id=?`, [rootCause, "investigating", nowIso(), incidentId]);
  await logAudit("support_engineer_agent", "ROOT_CAUSE_ANALYSIS", "incident", incidentId, { rootCause, actions });
  return { rootCause, actions };
}

export async function analyzeImpact(incidentId) {
  const incident = await get(`SELECT * FROM incidents WHERE id=?`, [incidentId]);
  if (!incident) throw new Error("Incident not found");
  const pipeline = await get(`SELECT name FROM pipelines WHERE id=?`, [incident.pipeline_id]);

  const impact = {
    tables: [`analytics.${pipeline?.name || "unknown"}_metrics`],
    dashboards: ["Revenue Dashboard", "Operations Dashboard"],
    applications: ["Power BI", "Tableau"],
  };

  await run(`UPDATE incidents SET impact_json=?, updated_at=? WHERE id=?`, [JSON.stringify(impact), nowIso(), incidentId]);
  await logAudit("support_engineer_agent", "IMPACT_ANALYSIS", "incident", incidentId, impact);
  return impact;
}

export async function remediateIncident(incidentId, actionType = "job_rerun") {
  const incident = await get(`SELECT * FROM incidents WHERE id=?`, [incidentId]);
  if (!incident) throw new Error("Incident not found");

  const allowed = PLATFORM_CONFIG?.agents?.support_engineer?.auto_remediation?.allowed_actions || ["job_rerun", "cluster_restart", "sql_patch"];
  const blocked = PLATFORM_CONFIG?.agents?.support_engineer?.auto_remediation?.blocked_actions || ["schema_deletion"];

  if (blocked.includes(actionType)) {
    throw new Error(`Action ${actionType} is blocked by guardrails`);
  }
  if (!allowed.includes(actionType)) {
    throw new Error(`Action ${actionType} is not allowed`);
  }

  if (incident.pipeline_id && actionType === "job_rerun") {
    await run(`UPDATE pipelines SET status='running', updated_at=? WHERE id=?`, [nowIso(), incident.pipeline_id]);
    setTimeout(async () => {
      await run(`UPDATE pipelines SET status='healthy', quality_score=96, updated_at=? WHERE id=?`, [nowIso(), incident.pipeline_id]);
    }, 2000);
  }

  const remediation = { action: actionType, executed_at: nowIso(), success: true };
  await run(
    `UPDATE incidents SET remediation_json=?, status='resolved', updated_at=? WHERE id=?`,
    [JSON.stringify(remediation), nowIso(), incidentId]
  );
  await logAudit("support_engineer_agent", "REMEDIATION_EXECUTED", "incident", incidentId, remediation);
  return remediation;
}

export async function runSqlValidation(sqlText) {
  const findings = [];
  if (/select\s+\*/i.test(sqlText)) findings.push("Avoid SELECT * for production pipelines");
  if (/drop\s+table|truncate|delete\s+from/i.test(sqlText)) findings.push("Unsafe destructive SQL detected");
  if (!/where/i.test(sqlText)) findings.push("No WHERE clause detected; potential full scan");
  return {
    passed: findings.every((f) => !f.includes("Unsafe")),
    findings,
    piiExposure: /email|phone|ssn/i.test(sqlText) ? "possible" : "none",
  };
}

export async function runDataQuality(pipelineId) {
  const checks = [
    { name: "row_count_anomalies", status: Math.random() > 0.1 ? "pass" : "fail" },
    { name: "null_spikes", status: Math.random() > 0.1 ? "pass" : "fail" },
    { name: "schema_drift", status: Math.random() > 0.2 ? "pass" : "fail" },
    { name: "freshness_sla", status: Math.random() > 0.15 ? "pass" : "fail" },
  ];

  for (const check of checks) {
    await run(
      `INSERT INTO quality_checks (id,pipeline_id,check_name,status,details,checked_at)
       VALUES (?,?,?,?,?,?)`,
      [uuidv4(), pipelineId, check.name, check.status, JSON.stringify({ auto: true }), nowIso()]
    );
  }

  const passCount = checks.filter((c) => c.status === "pass").length;
  const score = Math.round((passCount / checks.length) * 100);
  await run(`UPDATE pipelines SET quality_score=?, updated_at=? WHERE id=?`, [score, nowIso(), pipelineId]);
  await logAudit("data_quality_agent", "RUN_QUALITY", "pipeline", pipelineId, { score, checks });
  return { score, checks };
}

export async function runCostAnalysis() {
  const pipelines = await all(`SELECT id FROM pipelines LIMIT 25`);
  for (const p of pipelines) {
    await run(
      `INSERT INTO cost_metrics (id,pipeline_id,metric_name,metric_value,measured_at)
       VALUES (?,?,?,?,?)`,
      [uuidv4(), p.id, "runtime_minutes", 5 + Math.random() * 20, nowIso()]
    );
    await run(
      `INSERT INTO cost_metrics (id,pipeline_id,metric_name,metric_value,measured_at)
       VALUES (?,?,?,?,?)`,
      [uuidv4(), p.id, "idle_compute_minutes", Math.random() * 10, nowIso()]
    );
  }
  await logAudit("cost_optimization_agent", "RUN_COST_ANALYSIS", "platform", null, { sample: pipelines.length });
}
