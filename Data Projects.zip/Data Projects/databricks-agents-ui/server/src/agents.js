import { v4 as uuidv4 } from "uuid";
import { PLATFORM_CONFIG } from "./config.js";
import { all, get, run, logAudit } from "./db.js";

const activeTimers = new Map();

function nowIso() {
  return new Date().toISOString();
}

function extractSqlFromKpi(definition, pipelineName) {
  const def = definition.toLowerCase();
  if (def.includes("retention")) {
    return `
WITH users_30d AS (
  SELECT DISTINCT user_id
  FROM raw.events
  WHERE event_date >= DATE('now', '-30 day')
), total_users AS (
  SELECT COUNT(DISTINCT user_id) AS total_cnt
  FROM raw.users
)
SELECT
  '${pipelineName}' AS metric_name,
  (SELECT COUNT(*) FROM users_30d) * 100.0 / (SELECT total_cnt FROM total_users) AS metric_value,
  CURRENT_TIMESTAMP AS computed_at;
`.trim();
  }
  return `SELECT '${pipelineName}' AS metric_name, COUNT(*) AS metric_value, CURRENT_TIMESTAMP AS computed_at FROM raw.events;`;
}

function hashText(input) {
  let h = 0;
  for (let i = 0; i < input.length; i += 1) {
    h = (h << 5) - h + input.charCodeAt(i);
    h |= 0;
  }
  return Math.abs(h);
}

export async function recordPipelineRun(pipelineId, options = {}) {
  const pipeline = await get(`SELECT * FROM pipelines WHERE id=?`, [pipelineId]);
  if (!pipeline) throw new Error("Pipeline not found");

  const status = options.status || "healthy";
  const durationSec = Number(options.durationSec ?? (200 + (hashText(pipelineId) % 180)));
  const rowsProcessed = Number(options.rowsProcessed ?? (10000 + (hashText(`${pipelineId}:rows`) % 120000)));
  const dqScore = Number(options.dqScore ?? (status === "failed" ? 62 : 90 + (hashText(`${pipelineId}:dq`) % 8)));
  const errorStage = status === "failed" ? options.errorStage || "transform" : null;
  const errorMessage =
    status === "failed"
      ? options.errorMessage || `Deterministic mock failure in ${errorStage} stage`
      : null;

  const finishedAt = nowIso();
  const startedAt = new Date(new Date(finishedAt).getTime() - durationSec * 1000).toISOString();

  await run(
    `INSERT INTO pipeline_runs (id,pipeline_id,trigger_source,status,started_at,finished_at,duration_sec,rows_processed,error_stage,error_message,cost_usd,dq_score)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
    [
      uuidv4(),
      pipelineId,
      options.triggerSource || "manual",
      status,
      startedAt,
      finishedAt,
      durationSec,
      rowsProcessed,
      errorStage,
      errorMessage,
      Number((1.1 + durationSec / 120 + rowsProcessed / 50000).toFixed(2)),
      dqScore,
    ]
  );

  await run(`UPDATE pipelines SET status=?, quality_score=?, updated_at=? WHERE id=?`, [status, dqScore, nowIso(), pipelineId]);

  if (status === "failed") {
    const existing = await get(
      `SELECT id FROM incidents WHERE pipeline_id=? AND status IN ('open','investigating') ORDER BY updated_at DESC LIMIT 1`,
      [pipelineId]
    );
    if (!existing) {
      await run(
        `INSERT INTO incidents (id,pipeline_id,severity,category,message,status,created_at,updated_at)
         VALUES (?,?,?,?,?,?,?,?)`,
        [
          uuidv4(),
          pipelineId,
          "high",
          "job_failure",
          `Pipeline ${pipeline.name} failed at ${errorStage} stage`,
          "open",
          nowIso(),
          nowIso(),
        ]
      );
    }
  }

  return { status, durationSec, rowsProcessed, dqScore, errorStage, errorMessage };
}

async function createTask(runId, agentName, taskName) {
  const id = uuidv4();
  await run(
    `INSERT INTO agent_tasks (id,run_id,agent_name,task_name,status,started_at)
     VALUES (?,?,?,?,?,?)`,
    [id, runId, agentName, taskName, "running", nowIso()]
  );
  return id;
}

async function completeTask(taskId, result = {}) {
  await run(
    `UPDATE agent_tasks SET status=?, result_json=?, finished_at=? WHERE id=?`,
    ["completed", JSON.stringify(result), nowIso(), taskId]
  );
}

async function failTask(taskId, error) {
  await run(
    `UPDATE agent_tasks SET status=?, result_json=?, finished_at=? WHERE id=?`,
    ["failed", JSON.stringify({ error }), nowIso(), taskId]
  );
}

export async function runKpiToPipelineFlow(kpiId, environment = "dev") {
  const kpi = await get(`SELECT * FROM kpis WHERE id=?`, [kpiId]);
  if (!kpi) throw new Error("KPI not found");

  const runId = uuidv4();
  await run(
    `INSERT INTO agent_runs (id,run_type,trigger_payload,status,started_at)
     VALUES (?,?,?,?,?)`,
    [runId, "kpi_to_pipeline", JSON.stringify({ kpiId, environment }), "running", nowIso()]
  );

  const planTask = await createTask(runId, "planner", "Break request into tasks");
  const deDiscoverTask = await createTask(runId, "data_engineer", "Metadata discovery");
  const deBuildTask = await createTask(runId, "data_engineer", "Generate SQL + DLT pipeline");
  const reviewerTask = await createTask(runId, "reviewer", "Governance + SQL validation");
  const deployTask = await createTask(runId, "data_engineer", "Deployment automation");
  const qualityTask = await createTask(runId, "data_quality", "Setup DQ checks");

  const pipelineName = `pipe_${kpi.name}_${Date.now()}`;
  const sqlText = extractSqlFromKpi(kpi.definition, pipelineName);

  const timer = setTimeout(async () => {
    try {
      await completeTask(planTask, { tasks: 6, assigned: true });
      await completeTask(deDiscoverTask, { discovered_datasets: ["raw.events", "raw.users"] });

      await completeTask(deBuildTask, {
        generated_sql: sqlText,
        dlt_pipeline_name: pipelineName,
        schedule_cron: "0 */6 * * *",
      });

      const violation = /drop\s+table|delete\s+from/i.test(sqlText);
      if (violation) {
        await failTask(reviewerTask, "Unsafe SQL detected by reviewer");
        await run(`UPDATE agent_runs SET status=?, finished_at=? WHERE id=?`, ["failed", nowIso(), runId]);
        await logAudit("reviewer_agent", "BLOCK_PIPELINE", "agent_run", runId, { reason: "unsafe_sql" });
        return;
      }

      await completeTask(reviewerTask, {
        sql_efficiency: "pass",
        governance: "pass",
        pii_exposure: "none",
        schema_compatibility: "pass",
      });

      const pipelineId = uuidv4();
      await run(
        `INSERT INTO pipelines (id,kpi_id,name,status,sql_text,schedule_cron,environment,quality_score,created_at,updated_at)
         VALUES (?,?,?,?,?,?,?,?,?,?)`,
        [pipelineId, kpi.id, pipelineName, "healthy", sqlText, "0 */6 * * *", environment, 95, nowIso(), nowIso()]
      );
      await recordPipelineRun(pipelineId, {
        triggerSource: "agent_generated",
        status: "healthy",
        durationSec: 165,
        rowsProcessed: 18000,
        dqScore: 95,
      });

      await completeTask(deployTask, { pipeline_id: pipelineId, environment, deployed: true });

      const checks = [
        ["row_count_anomalies", "pass"],
        ["null_spikes", "pass"],
        ["schema_drift", "pass"],
        ["freshness_sla", "pass"],
      ];
      for (const [checkName, status] of checks) {
        await run(
          `INSERT INTO quality_checks (id,pipeline_id,check_name,status,details,checked_at)
           VALUES (?,?,?,?,?,?)`,
          [uuidv4(), pipelineId, checkName, status, JSON.stringify({ source: "data_quality_agent" }), nowIso()]
        );
      }

      await completeTask(qualityTask, { checks_configured: 4 });

      await run(`UPDATE agent_runs SET status=?, finished_at=? WHERE id=?`, ["completed", nowIso(), runId]);
      await logAudit("planner_agent", "RUN_COMPLETED", "agent_run", runId, { kpiId, pipelineName });
    } catch (error) {
      await failTask(deployTask, error.message);
      await run(`UPDATE agent_runs SET status=?, finished_at=? WHERE id=?`, ["failed", nowIso(), runId]);
      await logAudit("system", "RUN_FAILED", "agent_run", runId, { error: error.message });
    }
  }, 1200);

  activeTimers.set(runId, timer);
  return { runId };
}

export async function detectIncidents() {
  const failedPipelines = await all(`SELECT id, name FROM pipelines WHERE status='failed' LIMIT 10`);
  const newItems = [];
  for (const p of failedPipelines) {
    const exists = await get(
      `SELECT id FROM incidents WHERE pipeline_id=? AND status IN ('open','investigating') ORDER BY created_at DESC LIMIT 1`,
      [p.id]
    );
    if (!exists) {
      const id = uuidv4();
      await run(
        `INSERT INTO incidents (id,pipeline_id,severity,category,message,status,created_at,updated_at)
         VALUES (?,?,?,?,?,?,?,?)`,
        [id, p.id, "high", "job_failure", `Pipeline ${p.name} failed`, "open", nowIso(), nowIso()]
      );
      newItems.push(id);
    }
  }
  await logAudit("support_engineer_agent", "DETECT_INCIDENTS", "incident", null, { created: newItems.length });
  return newItems;
}

export async function analyzeRootCause(incidentId) {
  const incident = await get(`SELECT * FROM incidents WHERE id=?`, [incidentId]);
  if (!incident) throw new Error("Incident not found");

  const analytics = await getIncidentAnalytics(incidentId);
  const rootCause = analytics.rootCause.summary;
  const actions = analytics.recommendedActions;

  await run(`UPDATE incidents SET root_cause=?, status=?, updated_at=? WHERE id=?`, [rootCause, "investigating", nowIso(), incidentId]);
  await logAudit("support_engineer_agent", "ROOT_CAUSE_ANALYSIS", "incident", incidentId, {
    rootCause,
    confidence: analytics.rootCause.confidence,
    actions,
  });
  return { rootCause, actions, confidence: analytics.rootCause.confidence, evidence: analytics.rootCause.evidence };
}

export async function analyzeImpact(incidentId) {
  const incident = await get(`SELECT * FROM incidents WHERE id=?`, [incidentId]);
  if (!incident) throw new Error("Incident not found");
  const analytics = await getIncidentAnalytics(incidentId);
  const impact = analytics.blastRadius;

  await run(`UPDATE incidents SET impact_json=?, updated_at=? WHERE id=?`, [JSON.stringify(impact), nowIso(), incidentId]);
  await logAudit("support_engineer_agent", "IMPACT_ANALYSIS", "incident", incidentId, impact);
  return impact;
}

export async function remediateIncident(incidentId, actionType = "job_rerun") {
  const incident = await get(`SELECT * FROM incidents WHERE id=?`, [incidentId]);
  if (!incident) throw new Error("Incident not found");

  const allowed = PLATFORM_CONFIG?.agents?.support_engineer?.auto_remediation?.allowed_actions || ["job_rerun", "cluster_restart", "sql_patch"];
  const blocked = PLATFORM_CONFIG?.agents?.support_engineer?.auto_remediation?.blocked_actions || ["schema_deletion"];

  if (blocked.includes(actionType)) {
    throw new Error(`Action ${actionType} is blocked by guardrails`);
  }
  if (!allowed.includes(actionType)) {
    throw new Error(`Action ${actionType} is not allowed`);
  }

  if (incident.pipeline_id && actionType === "job_rerun") {
    await run(`UPDATE pipelines SET status='running', updated_at=? WHERE id=?`, [nowIso(), incident.pipeline_id]);
    setTimeout(async () => {
      await recordPipelineRun(incident.pipeline_id, {
        triggerSource: "support_remediation",
        status: "healthy",
        durationSec: 210,
        rowsProcessed: 24000,
        dqScore: 96,
      });
    }, 1400);
  }

  if (incident.pipeline_id && actionType === "cluster_restart") {
    await recordPipelineRun(incident.pipeline_id, {
      triggerSource: "support_remediation",
      status: "healthy",
      durationSec: 245,
      rowsProcessed: 21000,
      dqScore: 94,
    });
  }

  if (incident.pipeline_id && actionType === "sql_patch") {
    await recordPipelineRun(incident.pipeline_id, {
      triggerSource: "support_remediation",
      status: "healthy",
      durationSec: 265,
      rowsProcessed: 22000,
      dqScore: 95,
    });
  }

  const remediation = { action: actionType, executed_at: nowIso(), success: true };
  await run(
    `UPDATE incidents SET remediation_json=?, status='resolved', updated_at=? WHERE id=?`,
    [JSON.stringify(remediation), nowIso(), incidentId]
  );
  await logAudit("support_engineer_agent", "REMEDIATION_EXECUTED", "incident", incidentId, remediation);
  return remediation;
}

export async function runSqlValidation(sqlText) {
  const findings = [];
  if (/select\s+\*/i.test(sqlText)) findings.push("Avoid SELECT * for production pipelines");
  if (/drop\s+table|truncate|delete\s+from/i.test(sqlText)) findings.push("Unsafe destructive SQL detected");
  if (!/where/i.test(sqlText)) findings.push("No WHERE clause detected; potential full scan");
  return {
    passed: findings.every((f) => !f.includes("Unsafe")),
    findings,
    piiExposure: /email|phone|ssn/i.test(sqlText) ? "possible" : "none",
  };
}

export async function runDataQuality(pipelineId) {
  const seed = hashText(`${pipelineId}:${new Date().toISOString().slice(0, 13)}`);
  const failAt = seed % 7;
  const checks = [
    { name: "row_count_anomalies", status: failAt === 0 ? "fail" : "pass" },
    { name: "null_spikes", status: failAt === 2 ? "fail" : "pass" },
    { name: "schema_drift", status: failAt === 4 ? "fail" : "pass" },
    { name: "freshness_sla", status: failAt === 6 ? "fail" : "pass" },
  ];

  for (const check of checks) {
    await run(
      `INSERT INTO quality_checks (id,pipeline_id,check_name,status,details,checked_at)
       VALUES (?,?,?,?,?,?)`,
      [uuidv4(), pipelineId, check.name, check.status, JSON.stringify({ auto: true }), nowIso()]
    );
  }

  const passCount = checks.filter((c) => c.status === "pass").length;
  const score = Math.round((passCount / checks.length) * 100);
  await run(`UPDATE pipelines SET quality_score=?, updated_at=? WHERE id=?`, [score, nowIso(), pipelineId]);
  await logAudit("data_quality_agent", "RUN_QUALITY", "pipeline", pipelineId, { score, checks });
  return { score, checks };
}

export async function runCostAnalysis() {
  const pipelines = await all(`SELECT id FROM pipelines LIMIT 25`);
  for (let index = 0; index < pipelines.length; index += 1) {
    const p = pipelines[index];
    const runWindow = await get(
      `SELECT COALESCE(AVG(duration_sec), 240) as avg_duration,
              COALESCE(AVG(rows_processed), 15000) as avg_rows
       FROM pipeline_runs
       WHERE pipeline_id=?`,
      [p.id]
    );
    const runtimeMinutes = Number((runWindow.avg_duration / 60).toFixed(2));
    const idleMinutes = Number((Math.max(0.8, 6 - runtimeMinutes) + (index % 3) * 0.5).toFixed(2));
    await run(
      `INSERT INTO cost_metrics (id,pipeline_id,metric_name,metric_value,measured_at)
       VALUES (?,?,?,?,?)`,
      [uuidv4(), p.id, "runtime_minutes", runtimeMinutes, nowIso()]
    );
    await run(
      `INSERT INTO cost_metrics (id,pipeline_id,metric_name,metric_value,measured_at)
       VALUES (?,?,?,?,?)`,
      [uuidv4(), p.id, "idle_compute_minutes", idleMinutes, nowIso()]
    );
    await run(
      `INSERT INTO cost_metrics (id,pipeline_id,metric_name,metric_value,measured_at)
       VALUES (?,?,?,?,?)`,
      [uuidv4(), p.id, "rows_processed", Number(runWindow.avg_rows.toFixed(0)), nowIso()]
    );
  }
  await logAudit("cost_optimization_agent", "RUN_COST_ANALYSIS", "platform", null, { sample: pipelines.length });
}

export async function getIncidentAnalytics(incidentId) {
  const incident = await get(`SELECT * FROM incidents WHERE id=?`, [incidentId]);
  if (!incident) throw new Error("Incident not found");

  const pipeline = await get(
    `SELECT p.*, k.name as kpi_name
     FROM pipelines p
     LEFT JOIN kpis k ON k.id = p.kpi_id
     WHERE p.id=?`,
    [incident.pipeline_id]
  );
  const runs = await all(
    `SELECT * FROM pipeline_runs WHERE pipeline_id=? ORDER BY started_at DESC LIMIT 20`,
    [incident.pipeline_id]
  );

  const totalRuns = runs.length;
  const failedRuns = runs.filter((r) => r.status === "failed");
  const latestFailed = failedRuns[0] || null;
  const avgDurationSec = totalRuns
    ? Number((runs.reduce((acc, item) => acc + Number(item.duration_sec || 0), 0) / totalRuns).toFixed(1))
    : 0;
  const avgCost = totalRuns
    ? Number((runs.reduce((acc, item) => acc + Number(item.cost_usd || 0), 0) / totalRuns).toFixed(2))
    : 0;
  const failureRate = totalRuns ? Number((failedRuns.length / totalRuns).toFixed(2)) : 0;

  const stage = latestFailed?.error_stage || (incident.category === "sla_breach" ? "extract" : "transform");
  const stageReasons = {
    extract: "Upstream source latency and ingestion backlog",
    transform: "Transformation stage resource pressure and SQL skew",
    load: "Warehouse write contention during load step",
  };

  const recommendedActions =
    stage === "extract"
      ? ["job_rerun", "sql_patch"]
      : stage === "load"
        ? ["cluster_restart", "job_rerun"]
        : ["job_rerun", "cluster_restart", "sql_patch"];

  const confidence = Math.min(96, Math.round(62 + failureRate * 28 + (latestFailed ? 8 : 0)));
  const rootSummary = `${stageReasons[stage] || "Pipeline instability detected"} in pipeline ${pipeline?.name || "unknown"}`;

  return {
    incident: {
      id: incident.id,
      severity: incident.severity,
      status: incident.status,
      category: incident.category,
    },
    pipeline: {
      id: pipeline?.id,
      name: pipeline?.name,
      environment: pipeline?.environment,
      kpi: pipeline?.kpi_name || "unmapped_kpi",
    },
    health: {
      totalRuns,
      failedRuns: failedRuns.length,
      failureRate,
      avgDurationSec,
      avgCost,
      latestStatus: runs[0]?.status || pipeline?.status || "unknown",
    },
    rootCause: {
      summary: rootSummary,
      confidence,
      evidence: {
        latestFailedRunId: latestFailed?.id || null,
        errorStage: stage,
        errorMessage: latestFailed?.error_message || "No explicit error message captured",
      },
    },
    recommendedActions,
    blastRadius: {
      tables: [`analytics.${pipeline?.name || "unknown"}_metrics`],
      dashboards: ["Revenue Dashboard", "Operations Dashboard", "Customer Health Board"],
      applications: ["Power BI", "Tableau", "Internal Data API"],
      impactedKpi: pipeline?.kpi_name || "unknown",
    },
    trend: runs
      .slice(0, 8)
      .reverse()
      .map((r) => ({
        startedAt: r.started_at,
        status: r.status,
        durationSec: Number(r.duration_sec || 0),
        rowsProcessed: Number(r.rows_processed || 0),
      })),
  };
}
