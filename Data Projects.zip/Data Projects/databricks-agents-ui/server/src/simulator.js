import { all, run } from "./db.js";
import { recordPipelineRun } from "./agents.js";

const inFlight = new Set();
let schedulerTimer = null;

function hashText(input) {
  let h = 0;
  for (let i = 0; i < input.length; i += 1) {
    h = (h << 5) - h + input.charCodeAt(i);
    h |= 0;
  }
  return Math.abs(h);
}

async function executePipeline(pipeline) {
  if (!pipeline?.id || inFlight.has(pipeline.id)) return;
  inFlight.add(pipeline.id);
  await run(`UPDATE pipelines SET status='running', updated_at=? WHERE id=?`, [new Date().toISOString(), pipeline.id]);

  const delayMs = 5000 + (hashText(`${pipeline.id}:${Date.now()}`) % 7000);
  setTimeout(async () => {
    try {
      const failSignal = hashText(`${pipeline.id}:${new Date().toISOString().slice(0, 16)}`) % 10;
      const shouldFail = pipeline.environment === "prod" ? failSignal <= 2 : failSignal <= 1;
      await recordPipelineRun(pipeline.id, {
        triggerSource: "continuous_scheduler",
        status: shouldFail ? "failed" : "healthy",
        errorStage: shouldFail ? "transform" : null,
        errorMessage: shouldFail ? "Scheduled run detected transformation memory pressure" : null,
      });
    } catch {
      await run(`UPDATE pipelines SET status='failed', updated_at=? WHERE id=?`, [new Date().toISOString(), pipeline.id]);
    } finally {
      inFlight.delete(pipeline.id);
    }
  }, delayMs);
}

async function tick() {
  const candidates = await all(
    `SELECT id, environment, status
     FROM pipelines
     WHERE status != 'running'
     ORDER BY updated_at ASC
     LIMIT 36`
  );
  const parallelRuns = Math.min(4, candidates.length);
  for (let i = 0; i < parallelRuns; i += 1) {
    const item = candidates[i];
    await executePipeline(item);
  }
}

export function startPlatformSimulator() {
  if (schedulerTimer) return;
  tick();
  schedulerTimer = setInterval(() => {
    tick().catch(() => {
      // no-op, scheduler should continue running
    });
  }, 10000);
}
