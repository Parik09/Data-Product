# Autonomous Data Engineering & Support AI Platform

Modern full-stack app aligned to your requirement document.

## Stack
- React + Vite UI (gold, red, brown, blue theme)
- Express API
- SQLite database (`server/data/platform.db`)
- Config-driven behavior from `../databricks-agents/config/config.yaml`

## Run
```bash
npm install
npm run dev
```

- UI: `http://localhost:5173`
- API: `http://localhost:8787/api`

## What is implemented

### Personas and pages
- **Data Engineer Agent**: KPI intake, metadata-driven pipeline generation flow
- **Support Engineer Agent**: failure detection, root-cause, impact, remediation
- **Planner Agent**: task decomposition and run planning
- **Reviewer Agent**: SQL safety/governance validation
- **Data Quality Agent**: row/null/schema/freshness checks
- **Cost Optimization Agent**: runtime/idle compute analysis

### Functional workflows
- Create KPI -> run full agentic pipeline generation (`POST /api/kpis/:id/generate-pipeline`)
- Detect incidents (`POST /api/incidents/detect`)
- Root cause + impact + remediation actions with guardrails
- Pipeline run + validation + quality checks
- Cost analysis and audit logging
- Live run traces (`agent_runs`, `agent_tasks`)

### Database model
- `kpis`, `pipelines`, `incidents`
- `agent_runs`, `agent_tasks`
- `lineage_edges`, `quality_checks`, `cost_metrics`
- `audit_logs`

## Requirement mapping

- **FR-SE-01**: `/api/incidents/detect`
- **FR-SE-02**: `/api/incidents/:id/root-cause`
- **FR-SE-03**: `/api/incidents/:id/impact`
- **FR-SE-04**: `/api/incidents/:id/remediate` with allow/block guardrails
- **FR-DE-01**: KPI natural language intake (`POST /api/kpis`)
- **FR-DE-02/03**: SQL generation + planning in agent run
- **FR-DE-04**: deployment task in run + pipeline row creation
- **Planner/Reviewer/Quality/Cost agents**: dedicated endpoints and pages
- **Governance & auditability**: reviewer checks + `audit_logs`

## Notes
- The API includes a mock AI summarization endpoint (`/api/ai/summarize`).
- If you provide a real model key/provider, this endpoint can be upgraded to live LLM calls without changing UI workflows.
