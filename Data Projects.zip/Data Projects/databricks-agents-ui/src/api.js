const json = async (res) => {
  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      if (body?.error) message = body.error;
    } catch {
      // ignore
    }
    throw new Error(message);
  }
  return res.json();
};

export const api = {
  getDashboard: () => fetch("/api/dashboard").then(json),
  getOperationsLive: () => fetch("/api/operations/live").then(json),
  getConfig: () => fetch("/api/config").then(json),

  getKpis: () => fetch("/api/kpis").then(json),
  createKpi: (payload) =>
    fetch("/api/kpis", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }).then(json),
  generatePipelineFromKpi: (kpiId, environment = "dev") =>
    fetch(`/api/kpis/${kpiId}/generate-pipeline`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ environment }),
    }).then(json),
  createPipeline: (payload) =>
    fetch("/api/pipelines", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }).then(json),

  getPipelines: (status) =>
    fetch(`/api/pipelines${status ? `?status=${encodeURIComponent(status)}` : ""}`).then(json),
  runPipeline: (pipelineId, mode = "success") =>
    fetch(`/api/pipelines/${pipelineId}/run`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode: mode === "fail" ? "fail" : "success" }),
    }).then(json),
  getPipelineRuns: (pipelineId) => fetch(`/api/pipelines/${pipelineId}/runs`).then(json),
  validatePipeline: (pipelineId) =>
    fetch(`/api/pipelines/${pipelineId}/validate`, { method: "POST" }).then(json),
  runPipelineQuality: (pipelineId) =>
    fetch(`/api/pipelines/${pipelineId}/quality`, { method: "POST" }).then(json),

  getIncidents: () => fetch("/api/incidents").then(json),
  detectIncidents: () => fetch("/api/incidents/detect", { method: "POST" }).then(json),
  analyzeRootCause: (incidentId) =>
    fetch(`/api/incidents/${incidentId}/root-cause`, { method: "POST" }).then(json),
  getIncidentAnalytics: (incidentId) => fetch(`/api/incidents/${incidentId}/analytics`).then(json),
  analyzeImpact: (incidentId) => fetch(`/api/incidents/${incidentId}/impact`, { method: "POST" }).then(json),
  remediateIncident: (incidentId, actionType) =>
    fetch(`/api/incidents/${incidentId}/remediate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ actionType }),
    }).then(json),

  getAgentRuns: () => fetch("/api/agent-runs").then(json),
  getAgentRun: (runId) => fetch(`/api/agent-runs/${runId}`).then(json),

  getLineage: () => fetch("/api/lineage").then(json),
  runCostAnalysis: () => fetch("/api/cost/analyze", { method: "POST" }).then(json),
  getAudit: () => fetch("/api/audit").then(json),
  summarize: (prompt) =>
    fetch("/api/ai/summarize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt }),
    }).then(json),
};
