import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  Bot,
  Brain,
  CheckCircle2,
  Database,
  Gauge,
  GitBranch,
  Loader2,
  Play,
  Shield,
  Sparkles,
  Wallet,
  Wrench,
} from "lucide-react";
import { Bar, BarChart, Cell, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { api } from "./api";

const tabs = [
  { id: "dashboard", label: "Dashboard", icon: Gauge },
  { id: "data-engineer", label: "Data Engineer", icon: Database },
  { id: "support-engineer", label: "Support Engineer", icon: Shield },
  { id: "planner", label: "Planner", icon: Brain },
  { id: "reviewer", label: "Reviewer", icon: CheckCircle2 },
  { id: "quality", label: "Data Quality", icon: Sparkles },
  { id: "cost", label: "Cost", icon: Wallet },
  { id: "lineage", label: "Lineage", icon: GitBranch },
  { id: "runs", label: "Agent Runs", icon: Bot },
];

const colors = {
  gold: "#d4a017",
  red: "#b33939",
  brown: "#6f4e37",
  blue: "#2f5ea8",
};

function StatCard({ title, value, icon: Icon, tone }) {
  return (
    <div className="card stat-card" style={{ borderColor: tone }}>
      <div className="stat-top">
        <Icon size={18} color={tone} />
        <span className="stat-title">{title}</span>
      </div>
      <div className="stat-value">{value}</div>
    </div>
  );
}

function SectionHeader({ title, subtitle, right }) {
  return (
    <div className="section-header">
      <div>
        <h2>{title}</h2>
        {subtitle ? <p>{subtitle}</p> : null}
      </div>
      {right}
    </div>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [dashboard, setDashboard] = useState(null);
  const [operationsLive, setOperationsLive] = useState(null);
  const [kpis, setKpis] = useState([]);
  const [pipelines, setPipelines] = useState([]);
  const [incidents, setIncidents] = useState([]);
  const [lineage, setLineage] = useState({ nodes: [], edges: [] });
  const [runs, setRuns] = useState([]);
  const [selectedRun, setSelectedRun] = useState(null);
  const [config, setConfig] = useState(null);
  const [costSummary, setCostSummary] = useState([]);
  const [selectedIncident, setSelectedIncident] = useState(null);
  const [selectedKpi, setSelectedKpi] = useState(null);
  const [selectedPipeline, setSelectedPipeline] = useState(null);
  const [incidentAnalytics, setIncidentAnalytics] = useState(null);
  const [pipelineRuns, setPipelineRuns] = useState([]);
  const [notice, setNotice] = useState("");

  const [kpiForm, setKpiForm] = useState({ name: "", definition: "", targetValue: "", owner: "business_analyst" });
  const [pipelineForm, setPipelineForm] = useState({ name: "", sqlText: "", scheduleCron: "0 */6 * * *", environment: "dev" });

  const refreshAll = async () => {
    setError("");
    try {
      const [d, o, k, p, i, l, r, c] = await Promise.all([
        api.getDashboard(),
        api.getOperationsLive(),
        api.getKpis(),
        api.getPipelines(),
        api.getIncidents(),
        api.getLineage(),
        api.getAgentRuns(),
        api.getConfig(),
      ]);
      setDashboard(d);
      setOperationsLive(o);
      setKpis(k);
      setPipelines(p);
      setIncidents(i);
      setLineage(l);
      setRuns(r);
      setConfig(c);
      if (!selectedIncident && i.length > 0) setSelectedIncident(i[0]);
      if (!selectedKpi && k.length > 0) setSelectedKpi(k[0]);
      if (!selectedPipeline && p.length > 0) setSelectedPipeline(p[0]);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshAll();
    const timer = setInterval(refreshAll, 5000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const loadIncidentAnalytics = async () => {
      if (!selectedIncident?.id) {
        setIncidentAnalytics(null);
        return;
      }
      try {
        const analytics = await api.getIncidentAnalytics(selectedIncident.id);
        setIncidentAnalytics(analytics);
      } catch {
        setIncidentAnalytics(null);
      }
    };
    loadIncidentAnalytics();
  }, [selectedIncident?.id]);

  useEffect(() => {
    const loadRuns = async () => {
      if (!selectedPipeline?.id) {
        setPipelineRuns([]);
        return;
      }
      try {
        const runsData = await api.getPipelineRuns(selectedPipeline.id);
        setPipelineRuns(runsData);
      } catch {
        setPipelineRuns([]);
      }
    };
    loadRuns();
  }, [selectedPipeline?.id]);

  const statusChartData = useMemo(() => {
    const input = dashboard?.byStatus || [];
    return input.map((x) => ({ name: x.status, value: Number(x.count) }));
  }, [dashboard]);

  const incidentSeverityData = useMemo(() => {
    const input = dashboard?.incidentsBySeverity || [];
    return input.map((x) => ({ name: x.severity, value: Number(x.count) }));
  }, [dashboard]);

  const incidentTrendData = useMemo(() => {
    const trend = incidentAnalytics?.trend || [];
    return trend.map((item) => ({
      time: new Date(item.startedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      durationSec: item.durationSec,
      rowsK: Number((item.rowsProcessed / 1000).toFixed(1)),
      isFailure: item.status === "failed" ? 1 : 0,
    }));
  }, [incidentAnalytics]);

  const createKpi = async (e) => {
    e.preventDefault();
    try {
      await api.createKpi({
        name: kpiForm.name,
        definition: kpiForm.definition,
        targetValue: Number(kpiForm.targetValue || 0),
        owner: kpiForm.owner,
      });
      setKpiForm({ name: "", definition: "", targetValue: "", owner: "business_analyst" });
      setNotice("KPI created successfully.");
      await refreshAll();
    } catch (e2) {
      setNotice(e2.message);
    }
  };

  const generatePipeline = async () => {
    if (!selectedKpi) return;
    try {
      const out = await api.generatePipelineFromKpi(selectedKpi.id, "dev");
      setNotice(`Agent run started: ${out.runId}`);
      await refreshAll();
    } catch (e) {
      setNotice(e.message);
    }
  };

  const createPipeline = async (e) => {
    e.preventDefault();
    if (!selectedKpi) {
      setNotice("Select a KPI before creating a pipeline.");
      return;
    }
    try {
      await api.createPipeline({
        kpiId: selectedKpi.id,
        name: pipelineForm.name,
        sqlText: pipelineForm.sqlText,
        scheduleCron: pipelineForm.scheduleCron,
        environment: pipelineForm.environment,
      });
      setPipelineForm({ name: "", sqlText: "", scheduleCron: "0 */6 * * *", environment: "dev" });
      setNotice("Pipeline created and initial run recorded.");
      await refreshAll();
    } catch (e) {
      setNotice(e.message);
    }
  };

  const runPipelineNow = async (pipelineId, mode = "success") => {
    try {
      await api.runPipeline(pipelineId, mode === "fail" ? "fail" : "success");
      setNotice(mode === "fail" ? "Pipeline failed run simulated for support testing." : "Pipeline run triggered.");
      await refreshAll();
      if (selectedPipeline?.id === pipelineId) {
        const runsData = await api.getPipelineRuns(pipelineId);
        setPipelineRuns(runsData);
      }
    } catch (e) {
      setNotice(e.message);
    }
  };

  const detectIncidents = async () => {
    const out = await api.detectIncidents();
    setNotice(`Detected ${out.created} new incident(s)`);
    await refreshAll();
  };

  const doRootCause = async () => {
    if (!selectedIncident) return;
    const out = await api.analyzeRootCause(selectedIncident.id);
    setNotice(`Root cause analysis completed (${out.confidence}% confidence).`);
    const analytics = await api.getIncidentAnalytics(selectedIncident.id);
    setIncidentAnalytics(analytics);
    await refreshAll();
  };

  const doImpact = async () => {
    if (!selectedIncident) return;
    await api.analyzeImpact(selectedIncident.id);
    setNotice("Downstream impact analysis completed.");
    const analytics = await api.getIncidentAnalytics(selectedIncident.id);
    setIncidentAnalytics(analytics);
    await refreshAll();
  };

  const doRemediate = async (actionType) => {
    if (!selectedIncident) return;
    await api.remediateIncident(selectedIncident.id, actionType);
    setNotice(`Remediation executed: ${actionType}`);
    const analytics = await api.getIncidentAnalytics(selectedIncident.id);
    setIncidentAnalytics(analytics);
    await refreshAll();
  };

  const runValidation = async (pipelineId) => {
    const out = await api.validatePipeline(pipelineId);
    setNotice(out.passed ? "Validation passed" : `Validation warning: ${out.findings.join(", ")}`);
    await refreshAll();
  };

  const runQuality = async (pipelineId) => {
    const out = await api.runPipelineQuality(pipelineId);
    setNotice(`DQ score: ${out.score}`);
    await refreshAll();
  };

  const runCost = async () => {
    const out = await api.runCostAnalysis();
    setCostSummary(out.costs || []);
    setNotice("Cost optimization analysis executed.");
  };

  const selectRun = async (runId) => {
    const out = await api.getAgentRun(runId);
    setSelectedRun(out);
  };

  if (loading) {
    return (
      <div className="app-center">
        <Loader2 className="spin" /> Loading platform...
      </div>
    );
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <Sparkles size={20} />
          <div>
            <div className="brand-title">Lakehouse Agent OS</div>
            <div className="brand-sub">Databricks + Mosaic AI</div>
          </div>
        </div>
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button key={tab.id} className={`nav-btn ${activeTab === tab.id ? "active" : ""}`} onClick={() => setActiveTab(tab.id)}>
              <Icon size={16} /> {tab.label}
            </button>
          );
        })}
        <div className="config-box">
          <div>Support auto-remediation:</div>
          <strong>{config?.agents?.support_engineer?.auto_remediation?.enabled ? "Enabled" : "Disabled"}</strong>
          <div>Max pipelines:</div>
          <strong>{config?.scalability?.max_pipelines ?? "n/a"}</strong>
        </div>
      </aside>

      <main className="main-content">
        {error ? <div className="error-banner">{error}</div> : null}
        {notice ? <div className="notice-banner" onClick={() => setNotice("")}>{notice}</div> : null}

        {activeTab === "dashboard" && (
          <>
            <SectionHeader title="Autonomous Data Engineering & Support" subtitle="Live operational dashboard with fully clickable workflows" />
            <div className="grid-4">
              <StatCard title="Open Incidents" value={dashboard?.totals?.incidents} icon={AlertTriangle} tone={colors.red} />
              <StatCard title="Pipelines" value={dashboard?.totals?.pipelines} icon={GitBranch} tone={colors.blue} />
              <StatCard title="Avg Quality" value={`${dashboard?.totals?.quality}%`} icon={Sparkles} tone={colors.gold} />
              <StatCard
                title="Running Pipelines"
                value={operationsLive?.runningPipelines ?? dashboard?.totals?.activeAgentRuns}
                icon={Bot}
                tone={colors.brown}
              />
            </div>
            <div className="grid-2">
              <div className="card chart-card">
                <h3>Pipeline status</h3>
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={statusChartData}>
                    <XAxis dataKey="name" stroke="#ddd" />
                    <YAxis stroke="#ddd" />
                    <Tooltip />
                    <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                      {statusChartData.map((_, idx) => (
                        <Cell key={idx} fill={[colors.blue, colors.gold, colors.red, colors.brown][idx % 4]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="card chart-card">
                <h3>Incident severity</h3>
                <ResponsiveContainer width="100%" height={260}>
                  <PieChart>
                    <Pie data={incidentSeverityData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={65} outerRadius={95}>
                      {incidentSeverityData.map((_, idx) => (
                        <Cell key={idx} fill={[colors.red, colors.gold, colors.blue][idx % 3]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="card" style={{ marginTop: 12 }}>
              <h3>Live Pipeline Activity</h3>
              <div className="details">
                <div><strong>Completed in last hour:</strong> {operationsLive?.completedLastHour ?? 0}</div>
                <div><strong>Failed in last hour:</strong> {operationsLive?.failedLastHour ?? 0}</div>
              </div>
              <div className="list-wrap" style={{ marginTop: 10 }}>
                {(operationsLive?.latestRuns || []).slice(0, 10).map((run) => (
                  <div key={run.id} className="list-row plain">
                    <div>{run.pipeline_name || run.pipeline_id}</div>
                    <small>{run.status} · {Number(run.duration_sec || 0).toFixed(0)}s · rows {run.rows_processed}</small>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {activeTab === "data-engineer" && (
          <>
            <SectionHeader
              title="Data Engineer Agent"
              subtitle="FR-DE-01/02/03/04: KPI intake, metadata discovery, pipeline generation, deployment"
              right={<button className="primary" onClick={generatePipeline} disabled={!selectedKpi}><Play size={16} /> Generate Pipeline</button>}
            />
            <div className="grid-2">
              <div className="card">
                <h3>Create KPI</h3>
                <form onSubmit={createKpi} className="form-grid">
                  <input required placeholder="KPI name" value={kpiForm.name} onChange={(e) => setKpiForm((s) => ({ ...s, name: e.target.value }))} />
                  <input required placeholder="Natural language KPI definition" value={kpiForm.definition} onChange={(e) => setKpiForm((s) => ({ ...s, definition: e.target.value }))} />
                  <input placeholder="Target" type="number" value={kpiForm.targetValue} onChange={(e) => setKpiForm((s) => ({ ...s, targetValue: e.target.value }))} />
                  <input placeholder="Owner" value={kpiForm.owner} onChange={(e) => setKpiForm((s) => ({ ...s, owner: e.target.value }))} />
                  <button type="submit" className="primary">Create KPI</button>
                </form>
                <h3 style={{ marginTop: 18 }}>Create Pipeline</h3>
                <form onSubmit={createPipeline} className="form-grid">
                  <input required placeholder="Pipeline name" value={pipelineForm.name} onChange={(e) => setPipelineForm((s) => ({ ...s, name: e.target.value }))} />
                  <input required placeholder="SQL text" value={pipelineForm.sqlText} onChange={(e) => setPipelineForm((s) => ({ ...s, sqlText: e.target.value }))} />
                  <input placeholder="Schedule cron" value={pipelineForm.scheduleCron} onChange={(e) => setPipelineForm((s) => ({ ...s, scheduleCron: e.target.value }))} />
                  <input placeholder="Environment" value={pipelineForm.environment} onChange={(e) => setPipelineForm((s) => ({ ...s, environment: e.target.value }))} />
                  <button type="submit" className="primary" disabled={!selectedKpi}>Create Pipeline for Selected KPI</button>
                </form>
              </div>
              <div className="card">
                <h3>KPI Registry</h3>
                <div className="list-wrap">
                  {kpis.map((k) => (
                    <button key={k.id} className={`list-row ${selectedKpi?.id === k.id ? "selected" : ""}`} onClick={() => setSelectedKpi(k)}>
                      <div>{k.name}</div>
                      <small>{k.definition}</small>
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="grid-2">
              <div className="card">
                <h3>Pipeline Registry</h3>
                <div className="list-wrap">
                  {pipelines.slice(0, 40).map((p) => (
                    <button key={p.id} className={`list-row ${selectedPipeline?.id === p.id ? "selected" : ""}`} onClick={() => setSelectedPipeline(p)}>
                      <div>{p.name}</div>
                      <small>{p.environment} · {p.status} · quality {Number(p.quality_score || 0).toFixed(1)}</small>
                    </button>
                  ))}
                </div>
              </div>
              <div className="card">
                <h3>Pipeline Actions</h3>
                {selectedPipeline ? (
                  <>
                    <div className="details">
                      <div><strong>Name:</strong> {selectedPipeline.name}</div>
                      <div><strong>Status:</strong> {selectedPipeline.status}</div>
                      <div><strong>Environment:</strong> {selectedPipeline.environment}</div>
                    </div>
                    <div className="btn-row">
                      <button className="primary" onClick={() => runPipelineNow(selectedPipeline.id, "success")}>Run Healthy</button>
                      <button className="secondary" onClick={() => runPipelineNow(selectedPipeline.id, "fail")}>Simulate Failure</button>
                    </div>
                    <div className="btn-row">
                      <button className="secondary" onClick={() => runValidation(selectedPipeline.id)}>Validate SQL</button>
                      <button className="secondary" onClick={() => runQuality(selectedPipeline.id)}>Run DQ</button>
                    </div>
                    <h4 style={{ marginTop: 14 }}>Recent Pipeline Runs</h4>
                    <div className="list-wrap">
                      {pipelineRuns.slice(0, 8).map((run) => (
                        <div key={run.id} className="list-row plain">
                          <div>{run.status} · {run.trigger_source}</div>
                          <small>{Number(run.duration_sec).toFixed(0)}s · rows {run.rows_processed}</small>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <p>Select a pipeline</p>
                )}
              </div>
            </div>
          </>
        )}

        {activeTab === "support-engineer" && (
          <>
            <SectionHeader
              title="Support Engineer Agent"
              subtitle="FR-SE-01/02/03/04: detect failures, root-cause, impact, remediation"
              right={<button className="primary" onClick={detectIncidents}><Wrench size={16} /> Detect Incidents</button>}
            />
            <div className="grid-2">
              <div className="card">
                <h3>Incidents</h3>
                <div className="list-wrap">
                  {incidents.map((i) => (
                    <button key={i.id} className={`list-row ${selectedIncident?.id === i.id ? "selected" : ""}`} onClick={() => setSelectedIncident(i)}>
                      <div>{i.category}</div>
                      <small>{i.message}</small>
                    </button>
                  ))}
                </div>
              </div>
              <div className="card">
                <h3>Actions</h3>
                {selectedIncident ? (
                  <>
                    <div className="details">
                      <div><strong>Status:</strong> {selectedIncident.status}</div>
                      <div><strong>Severity:</strong> {selectedIncident.severity}</div>
                      <div><strong>Pipeline:</strong> {selectedIncident.pipeline_name || "unknown"}</div>
                    </div>
                    <div className="btn-row">
                      <button className="secondary" onClick={doRootCause}>Root Cause</button>
                      <button className="secondary" onClick={doImpact}>Impact</button>
                    </div>
                    <div className="btn-row">
                      <button className="primary" onClick={() => doRemediate("job_rerun")}>Job Rerun</button>
                      <button className="primary" onClick={() => doRemediate("cluster_restart")}>Cluster Restart</button>
                      <button className="primary" onClick={() => doRemediate("sql_patch")}>SQL Patch</button>
                    </div>
                    {incidentAnalytics ? (
                      <>
                        <h4 style={{ marginTop: 14 }}>Failure Analytics</h4>
                        <div className="metrics-grid">
                          <div className="metric-chip">
                            <span>Failure rate</span>
                            <strong>{(incidentAnalytics.health.failureRate * 100).toFixed(0)}%</strong>
                          </div>
                          <div className="metric-chip">
                            <span>Avg duration</span>
                            <strong>{incidentAnalytics.health.avgDurationSec}s</strong>
                          </div>
                          <div className="metric-chip">
                            <span>Avg cost</span>
                            <strong>${incidentAnalytics.health.avgCost}</strong>
                          </div>
                          <div className="metric-chip">
                            <span>Confidence</span>
                            <strong>{incidentAnalytics.rootCause.confidence}%</strong>
                          </div>
                        </div>

                        <div className="chart-card card" style={{ marginTop: 10 }}>
                          <h4>Run Trend</h4>
                          <ResponsiveContainer width="100%" height={180}>
                            <LineChart data={incidentTrendData}>
                              <XAxis dataKey="time" stroke="#9eb0ca" />
                              <YAxis stroke="#9eb0ca" />
                              <Tooltip />
                              <Line type="monotone" dataKey="durationSec" stroke={colors.blue} strokeWidth={2} dot={false} />
                              <Line type="monotone" dataKey="rowsK" stroke={colors.gold} strokeWidth={2} dot={false} />
                              <Line type="stepAfter" dataKey="isFailure" stroke={colors.red} strokeWidth={2} dot={false} />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>

                        <div className="incident-brief" style={{ marginTop: 10 }}>
                          <div><strong>Root cause:</strong> {incidentAnalytics.rootCause.summary}</div>
                          <div><strong>Evidence:</strong> {incidentAnalytics.rootCause.evidence.errorStage} - {incidentAnalytics.rootCause.evidence.errorMessage}</div>
                          <div><strong>Recommended:</strong> {incidentAnalytics.recommendedActions.join(", ")}</div>
                          <div><strong>Impacted KPI:</strong> {incidentAnalytics.blastRadius.impactedKpi}</div>
                        </div>
                      </>
                    ) : null}
                  </>
                ) : (
                  <p>Select an incident</p>
                )}
              </div>
            </div>
          </>
        )}

        {activeTab === "planner" && (
          <>
            <SectionHeader title="Planner Agent" subtitle="Break requests into tasks, assign agents, maintain execution plan" />
            <div className="card">
              <h3>Latest runs (execution plans)</h3>
              <div className="list-wrap">
                {runs.map((r) => (
                  <button key={r.id} className={`list-row ${selectedRun?.run?.id === r.id ? "selected" : ""}`} onClick={() => selectRun(r.id)}>
                    <div>{r.run_type}</div>
                    <small>{r.status} · {new Date(r.started_at).toLocaleString()}</small>
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {activeTab === "reviewer" && (
          <>
            <SectionHeader title="Reviewer Agent" subtitle="Validate SQL efficiency, governance, PII and schema compatibility" />
            <div className="card">
              <h3>Pipelines requiring validation</h3>
              <div className="list-wrap">
                {pipelines.slice(0, 20).map((p) => (
                  <div key={p.id} className="list-row plain">
                    <div>
                      <div>{p.name}</div>
                      <small>{p.environment} · {p.status}</small>
                    </div>
                    <button className="secondary" onClick={() => runValidation(p.id)}>Run Validation</button>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {activeTab === "quality" && (
          <>
            <SectionHeader title="Data Quality Agent" subtitle="row count anomalies, null spikes, schema drift, freshness SLA" />
            <div className="card">
              <h3>Run checks per pipeline</h3>
              <div className="list-wrap">
                {pipelines.slice(0, 20).map((p) => (
                  <div key={p.id} className="list-row plain">
                    <div>
                      <div>{p.name}</div>
                      <small>Current quality: {p.quality_score?.toFixed?.(1) ?? p.quality_score}</small>
                    </div>
                    <button className="secondary" onClick={() => runQuality(p.id)}>Run DQ</button>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {activeTab === "cost" && (
          <>
            <SectionHeader title="Cost Optimization Agent" subtitle="Analyze cluster utilization, job runtime, idle compute and storage growth" right={<button className="primary" onClick={runCost}>Run Cost Analysis</button>} />
            <div className="card">
              <h3>Cost telemetry (last run)</h3>
              <div className="list-wrap">
                {costSummary.length === 0 ? <p>No cost analysis run yet.</p> : null}
                {costSummary.map((c) => (
                  <div className="list-row plain" key={c.metric_name}>
                    <div>{c.metric_name}</div>
                    <strong>{c.avg_value}</strong>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {activeTab === "lineage" && (
          <>
            <SectionHeader title="Lineage & Impact" subtitle="Clickable lineage graph with downstream blast radius" />
            <div className="card">
              <div className="list-wrap">
                {lineage.edges.map((e) => (
                  <button key={e.id} className="list-row">
                    <div>{e.source_asset}</div>
                    <small>{e.edge_type} → {e.target_asset}</small>
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {activeTab === "runs" && (
          <>
            <SectionHeader title="Agentic Runs" subtitle="Actual orchestrated runs with task-level execution trace" />
            <div className="grid-2">
              <div className="card">
                <h3>Runs</h3>
                <div className="list-wrap">
                  {runs.map((r) => (
                    <button key={r.id} className={`list-row ${selectedRun?.run?.id === r.id ? "selected" : ""}`} onClick={() => selectRun(r.id)}>
                      <div>{r.run_type}</div>
                      <small>{r.status}</small>
                    </button>
                  ))}
                </div>
              </div>
              <div className="card">
                <h3>Task trace</h3>
                {selectedRun ? (
                  <div className="list-wrap">
                    {selectedRun.tasks.map((t) => (
                      <div key={t.id} className="list-row plain">
                        <div>{t.agent_name} · {t.task_name}</div>
                        <small>{t.status}</small>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p>Select a run</p>
                )}
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
